#pragma once
#include <string>
#include <iostream>

using namespace std;

class Appliance
{
protected:
	string id{};
	double weight{};

public:
	Appliance(string _id, double _weight); 
	virtual ~Appliance();

	double getWeight() const;
	virtual double consumedElerctricity() const = 0;
	virtual string toString() const;

	bool operator==(const Appliance& appliance);
	friend ostream& operator<<(ostream& stream, const Appliance&);
};


class Refrigerator : public Appliance
{
private:
	string electricityUsageClass{};
	bool hasFreezer{};

public:
	Refrigerator(string _id, double _weight, string _electricityUsageclass, bool _hasFreezer);
	~Refrigerator();

	double consumedElerctricity() const override;
	string toString() const;
	friend ostream& operator<<(ostream& stream, const Refrigerator&);

};

class DishWashing :public Appliance
{
private:
	double washingCycleLength{};
	double consumedElectricityForOneHour{};

public:
	DishWashing(string _id, double _weight, double _cycleLength, double _consumedenergy);
	~DishWashing();

	double consumedElerctricity() const override;
	string toString() const;
	friend ostream& operator<<(ostream& stream, const DishWashing& machine);
};
