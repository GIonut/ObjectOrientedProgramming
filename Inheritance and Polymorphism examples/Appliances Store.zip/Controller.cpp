#include "Controller.h"
#include <fstream>
#include <algorithm>

Controller::Controller(Repository& _repository):repository{_repository}
{
}

Controller::~Controller()
{
}

void Controller::addAppliance(shared_ptr<Appliance> appliance)
{
	this->repository.add(appliance);
}

const vector<shared_ptr<Appliance>>& Controller::getAppliances() const
{
	return this->repository.get();
}

vector<shared_ptr<Appliance>> Controller::getAllWithConsumedElectricityLessThen(double maxElectricity) const
{
	vector<shared_ptr<Appliance>> appliances = this->repository.get();
	vector<shared_ptr<Appliance>> filteredAppliances{};

	for (auto appliance : appliances)
	{
		if (appliance->consumedElerctricity() < maxElectricity)
			filteredAppliances.push_back(appliance);
	}

	return filteredAppliances;
}

void Controller::writeToFile(const string& filename, double consumedElectricity) const
{
	ofstream file(filename);
	vector<shared_ptr<Appliance>> appliances = this->repository.get();

	for (auto appliance : appliances)
	{
		if(appliance->consumedElerctricity() < consumedElectricity)
			file << appliance->toString() << "\n";
	}
}

vector<shared_ptr<Appliance>> Controller::sortByWeight() const
{
	vector<shared_ptr<Appliance>> appliances = this->repository.get();

	sort(appliances.begin(), appliances.end(), [&](auto i, auto j) { return i->getWeight() <= j->getWeight(); });

	return appliances;
}
