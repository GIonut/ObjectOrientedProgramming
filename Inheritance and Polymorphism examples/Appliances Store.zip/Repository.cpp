#include "Repository.h"
#include <vector>
#include <fstream>

Repository::Repository()
{
}

Repository::~Repository()
{
}

void Repository::add(shared_ptr<Appliance> _appliance)
{
	if (find_if(appliances.begin(), appliances.end(), [&](const shared_ptr<Appliance>& appliance) {return (*appliance) == (*_appliance); }) != appliances.end())
	{
		throw 1;// error message
	}

	this->appliances.push_back(_appliance);
}

const vector<shared_ptr<Appliance>>& Repository::get() const
{
	return this->appliances;
}
