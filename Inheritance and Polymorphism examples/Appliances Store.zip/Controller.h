#pragma once
#include "Repository.h"
#include <vector>
#include <memory>

class Controller
{
private:
	Repository& repository;

public:
	Controller(Repository& _repository);
	~Controller();

	void addAppliance(shared_ptr<Appliance> appliance);
	const vector<shared_ptr<Appliance>>& getAppliances() const;
	vector<shared_ptr<Appliance>> getAllWithConsumedElectricityLessThen(double maxElectricity) const;
	void writeToFile(const string& filename, double) const;
	vector<shared_ptr<Appliance>> sortByWeight() const;
};

