#pragma once
#include "Controller.h"
#include <string>

class Ui
{
private:
    Controller& controller;

public:

    Ui(Controller& _controller);
    ~Ui();

    void ui_run();

private:

    void ui_addAppliance();
    void ui_sortByWeight();
    void ui_print();
    void ui_saveToFile();
};

