#include "Appliance.h"
#include <sstream>

Appliance::Appliance(string _id, double _weight): id{_id}, weight{_weight}
{
}

Appliance::~Appliance()
{
}

double Appliance::getWeight() const
{
	return this->weight;
}

string Appliance::toString() const
{
	stringstream stream;
	stream << this->id << ',' << this->weight;
	return stream.str();
}

bool Appliance::operator==(const Appliance& appliance)
{
	if (this->id == appliance.id)
		return true;
	return false;
}

Refrigerator::Refrigerator(string _id, double _weight, string _electricityUsageclass, bool _hasFreezer) : Appliance{ _id, _weight }, electricityUsageClass{ _electricityUsageclass }, hasFreezer{_hasFreezer}
{
}

Refrigerator::~Refrigerator()
{
}

double Refrigerator::consumedElerctricity() const
{
	double consumedEnergy{};
	double x{};
	if (this->electricityUsageClass == "A")
		x = 3;
	else if (this->electricityUsageClass == "A+")
		x = 2.5;
	else if (this->electricityUsageClass == "A++")
		x = 2;

	consumedEnergy = 30 * x;

	if (this->hasFreezer)
		consumedEnergy += 20;

	return consumedEnergy;
}

string Refrigerator::toString() const
{
	stringstream stream;
	stream << this->id << "," << this->weight << "," << this->electricityUsageClass << "," << this->hasFreezer;
	return stream.str();
}

DishWashing::DishWashing(string _id, double _weight, double _cycleLength, double _consumedenergy) : Appliance{ _id, _weight }, washingCycleLength{ _cycleLength }, consumedElectricityForOneHour{ _consumedenergy }
{
}

DishWashing::~DishWashing()
{
}

double DishWashing::consumedElerctricity() const
{
	double consumedEnergy = this->consumedElectricityForOneHour*this->washingCycleLength*8;
	return consumedEnergy;
}

string DishWashing::toString() const
{
	stringstream stream;
	stream << this->id << "," << this->weight << "," << this->consumedElectricityForOneHour << "," << this->washingCycleLength;
	return stream.str();
}


ostream& operator<<(ostream& stream, const Appliance& appliance)
{
	stream << appliance.toString();
	return stream;
}

ostream& operator<<(ostream& stream, const Refrigerator& refrigerator)
{
	stream << refrigerator.toString();
	return stream;
}

ostream& operator<<(ostream& stream, const DishWashing& machine)
{
	stream << machine.toString();
	return stream;
}
