#include "Ui.h"

Ui::Ui(Controller& _controller):controller{_controller}
{
}

Ui::~Ui()
{
}

void print_menu()
{
	cout << "Choose an operation!\n";
	cout << "\t0. Exit\n";
	cout << "\t1. Add\n";
	cout << "\t2. Print\n";
	cout << "\t3. Sort\n";
	cout << "\t4. Save\n";
}
void Ui::ui_run()
{
	while (true)
	{
		print_menu();
		string command{};
		cin >> command;
		cin.ignore();

		if (command == "0")
			return;
		else if (command == "1")
		{
			try {
				this->ui_addAppliance();
			}
			catch (...)
			{
				cout << "An appliance with the same ID already exists!\n";
			}
		}
		else if (command == "2")
			this->ui_print();
		else if (command == "3")
			this->ui_sortByWeight();
		else if (command == "4")
			this->ui_saveToFile();
		else
			cout << "Please, choose a valid option!\n";
	}
}

void Ui::ui_addAppliance()
{
	string command{};
	cout << "\t\t1. Refrigerator\n";
	cout << "\t\t2. Dish washing machine\n";
	cin >> command;
	cin.ignore();

	string id{};
	double weight{};
	cout << "\t\t\tid: ";
	cin >> id;
	cin.ignore();
	cout << "\t\t\tweight: ";
	cin >> weight;
	cin.ignore();

	if (command == "1")
	{
		string electricityUsageClass{};
		bool hasFreezer{};
		cout << "\t\t\tusageClass: ";
		cin >> electricityUsageClass;
		cin.ignore();
		cout << "\t\t\thasFreezer: ";
		cin >> hasFreezer;
		cin.ignore();

		shared_ptr<Appliance> refrigerator = make_shared<Refrigerator>(id, weight, electricityUsageClass, hasFreezer);

		this->controller.addAppliance(refrigerator);

	}
	else if (command == "2")
	{
		double washingCycleLength{};
		double consumedElectricityForOneHour{};
		cout << "\t\t\tcycleLength: ";
		cin >> washingCycleLength;
		cin.ignore();
		cout << "\t\t\tconsumedElectricityForOneHour: ";
		cin >> consumedElectricityForOneHour;
		cin.ignore();

		shared_ptr<Appliance> dishWashing = make_shared<DishWashing>(id, weight, washingCycleLength, consumedElectricityForOneHour);

		this->controller.addAppliance(dishWashing);
	}
	
}

void Ui::ui_sortByWeight()
{
	vector<shared_ptr<Appliance>> appliances = this->controller.sortByWeight();

	for (auto appliance : appliances)
	{
		cout << appliance->toString() << "\n";
	}
}

void Ui::ui_print()
{
	vector<shared_ptr<Appliance>> appliances = this->controller.getAppliances();

	for (auto appliance : appliances)
	{
		cout << appliance->toString() << "\n";
	}

}

void Ui::ui_saveToFile()
{
	string filename{};
	cout << "\t\tProvide a filename: ";
	cin >> filename;
	cin.ignore();

	double consumedElectricity{};
	cout << "\t\tProvide the consumed electricity: ";
	cin >> consumedElectricity;
	cin.ignore();

	this->controller.writeToFile(filename, consumedElectricity);
}
