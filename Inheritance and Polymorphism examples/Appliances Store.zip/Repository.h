#pragma once
#include "Appliance.h"
#include <vector>
#include <memory>

class Repository
{
private:
	vector<shared_ptr<Appliance>> appliances;
	

public:
	Repository();
	~Repository();

	void add(shared_ptr<Appliance> appliance);
	const vector<shared_ptr<Appliance>>& get() const;

};

