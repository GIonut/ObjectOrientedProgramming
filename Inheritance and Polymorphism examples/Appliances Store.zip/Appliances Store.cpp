
#include <iostream>
#include "Ui.h"
#include "Repository.h"
#include "Controller.h"


void populate_repo(Repository& repository)
{
    shared_ptr<Appliance> appliance = make_shared<Refrigerator>("refr7100", 340, "A+", true);
    repository.add(appliance);

    appliance = make_shared<DishWashing>("dw1234", 120, 12, 3);
    repository.add(appliance);

    appliance = make_shared<Refrigerator>("refr5123", 145, "A++", false);
    repository.add(appliance);
}

int main()
{
    {
        Repository repository;

        populate_repo(repository);

        Controller controller{ repository };
        Ui ui{ controller };

        ui.ui_run();
    }
}

