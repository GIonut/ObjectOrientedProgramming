#include "Vegetables.h"
#include <algorithm>

Vegetables::Vegetables(Service& _service, QWidget *parent)
    : QMainWindow(parent), service{_service}
{
    ui.setupUi(this);
    this->populateList();
    this->showVegetables();
}

void Vegetables::populateList()
{
    this->ui.elementsListWidget->clear();

    vector<Domain> elements = this->service.getElements();
    string family{};

    for (int i = 0; i< elements.size(); i++)
    {
        if(elements[i].getFamily() != family)
            this->ui.elementsListWidget->addItem(QString::fromStdString(elements[i].getFamily()));

        family = elements[i].getFamily();
    }
}



int Vegetables::getSelectedIndex() const
{
    QModelIndexList selectedIndexes = this->ui.elementsListWidget->selectionModel()->selectedIndexes();
	int selectedIndex = selectedIndexes.at(0).row();
	return selectedIndex;
}

void Vegetables::showVegetables()
{
    QObject::connect(this->ui.elementsListWidget, &QListWidget::itemSelectionChanged, [this] {

        int selectedIndex = this->getSelectedIndex();

        if (selectedIndex < 0)
            return;

        vector<Domain> elements = this->service.getElements();
        Domain selectedElement = elements[selectedIndex];

        this->ui.vegetableListWidget->clear();

        for (const Domain& element : elements)
        {
            if (element.getFamily() == selectedElement.getFamily())
                this->ui.vegetableListWidget->addItem(QString::fromStdString(element.getName()) + " | " + QString::fromStdString(element.getParts()));
        }

    });
}

void Vegetables::searchVegetable()
{
    string name = this->ui.lineEdit->text().toStdString();
    string family{};
    vector<Domain> elements = this->service.getElements();

    for (const Domain& element : elements)
    {
        if (element.getName() == name)
        {
            this->ui.partsLabel->setText(QString::fromStdString(element.getParts()));
            family = element.getFamily();
        }
    }
    
    for (int i = 0; i < this->ui.elementsListWidget->count(); ++i)
    {
        QListWidgetItem* item = this->ui.elementsListWidget->item(i);
        if (item->text().toStdString() == family)
        {
            this->ui.elementsListWidget->setCurrentRow(i);
        }
        
    }
}

