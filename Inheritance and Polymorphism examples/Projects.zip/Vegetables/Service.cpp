#include "Service.h"
#include <algorithm>

vector<Domain> Service::getElements() const
{
	vector<Domain> elements = this->repo.get();

	sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getFamily() < j.getFamily(); });

	return elements;
}

vector<Domain> Service::filterElements(const string& family) const
{
	if (family == "")
		return this->repo.get();

	vector<Domain> elements = this->repo.get();
	vector<Domain> filteredElements;

	for (const Domain& element : elements)
	{
		if (element.getFamily() == family)
			filteredElements.push_back(element);
	}

	return filteredElements;
}

void Service::removeElement(const Domain& element)
{
	this->repo.remove(element);
}

void Service::addElement(const string& family, const string& name, const string& parts)
{
	Domain element{ family, name, parts };

	this->repo.add(element);
}

void Service::updateElement(const string& family, const string& name, const string& parts)
{
	Domain element{ family, name, parts };

	this->repo.update(element);
}
