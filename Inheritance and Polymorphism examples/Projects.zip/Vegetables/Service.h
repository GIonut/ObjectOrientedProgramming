#pragma once
#include "Repo.h"


class Service
{
private:
	Repo& repo;

public:
	Service(Repo& _repo) : repo{ _repo } {};
	~Service() {};

	vector<Domain> getElements() const;
	vector<Domain> filterElements(const string& category) const;
	void removeElement(const Domain& element);
	void addElement(const string& family, const string& name, const string& parts);
	void updateElement(const string& family, const string& name, const string& parts);

};

