#pragma once
#include <string>
#include <vector>

using namespace std;

class Domain
{
private:
	string family{};
	string name{};
	string parts{};

public:
	Domain() {};
	Domain(string _family, string _name, string _parts) : family{ _family }, name{ _name }, parts{ _parts } {};
	~Domain() {};

	const string& getFamily() const;
	const string& getName() const;
	const string& getParts() const;

	friend istream& operator>>(istream& stream, Domain& element);
	friend ostream& operator<<(ostream& stream, const Domain& element);

	bool operator==(const Domain& element) const;
};

