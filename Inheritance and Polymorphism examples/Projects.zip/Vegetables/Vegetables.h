#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Vegetables.h"
#include "Service.h"

class Vegetables : public QMainWindow
{
    Q_OBJECT

public:
    Vegetables(Service& _service, QWidget *parent = Q_NULLPTR);

private:
    Ui::VegetablesClass ui;
    Service& service;

    void populateList();
    int getSelectedIndex() const;
    //int getSelectedIndexVegetables() const;
    void showVegetables();
    

public slots:
    void searchVegetable();
    //void removeFromList();
    //void updateList();
    //void addToList();
    //void populateVegetables();
    //void populateLineEdits();

};
