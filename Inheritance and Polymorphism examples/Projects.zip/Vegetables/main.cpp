#include "Vegetables.h"
#include <QtWidgets/QApplication>
#include "Service.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Repo repo{ "Vegetables.txt" };
    Service service{ repo };

    Vegetables w{ service };
    w.show();
    return a.exec();
}
