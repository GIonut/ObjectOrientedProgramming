#include "Domain.h"
#include <istream>

const string& Domain::getFamily() const
{
	return this->family;
}

const string& Domain::getName() const
{
	return this->name;
}

const string& Domain::getParts() const
{
	return this->parts;
}

bool Domain::operator==(const Domain& element) const
{
	return this->family == element.family && this->name == element.name;
}

istream& operator>>(istream& stream, Domain& element)
{
	string line{};
	getline(stream, line);

	if (line.size() == 0)
		return stream;

	string attributes[3];
	int i = 0;
	int j = 0;
	while (j < line.size())
	{
		if (line[j] == '|')
		{
			i++;
		}
		else {
			attributes[i] += line[j];
		}
		j++;
	}

	element.family = attributes[0];
	element.name = attributes[1];
	element.parts = attributes[2];

	return stream;
}

ostream& operator<<(ostream& stream, const Domain& element)
{
	const string delimitator = "|";

	stream << element.family << delimitator << element.name << delimitator << element.parts << static_cast<string>("\n");
	return stream;
}
