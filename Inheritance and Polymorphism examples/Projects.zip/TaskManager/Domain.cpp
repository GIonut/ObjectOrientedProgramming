#include "Domain.h"
#include <istream>

const string& Domain::getDescription() const
{
	return this->description;
}

int Domain::getDuration() const
{
	return this->duration;
}

int Domain::getPriority() const
{
	return this->priority;
}

bool Domain::operator==(const Domain& element) const
{
	return this->description == element.description;
}

istream& operator>>(istream& stream, Domain& element)
{
	string line{};
	getline(stream, line);

	if (line.size() == 0)
		return stream;

	string attributes[3];
	int i = 0;
	int j = 0;
	while (j < line.size())
	{
		if (line[j] == '|')
		{
			i++;
		}
		else {
			attributes[i] += line[j];
		}
		j++;
	}

	element.description = attributes[0];
	element.duration = stoi(attributes[1]);
	element.priority = stoi(attributes[2]);

	return stream;
}

ostream& operator<<(ostream& stream, const Domain& element)
{
	const string delimitator = "|";

	stream << element.description << delimitator << element.duration << delimitator << element.priority << static_cast<string>("\n");
	return stream;
}
