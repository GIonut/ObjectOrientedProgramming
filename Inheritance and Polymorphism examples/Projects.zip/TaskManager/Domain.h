#pragma once
#pragma once
#include <string>
#include <vector>

using namespace std;

class Domain
{
private:
	string description{};
	int duration{};
	int priority{};

public:
	Domain() {};
	Domain(string _description, int _duration, int _priority) : description{ _description }, duration{ _duration }, priority{ _priority } {};
	~Domain() {};

	const string& getDescription() const;
	int getDuration() const;
	int getPriority() const;

	friend istream& operator>>(istream& stream, Domain& element);
	friend ostream& operator<<(ostream& stream, const Domain& element);

	bool operator==(const Domain& element) const;
};
