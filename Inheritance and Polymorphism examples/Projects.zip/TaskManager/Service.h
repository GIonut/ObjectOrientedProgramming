#pragma once
#include "Repo.h"


class Service
{
private:
	Repo& repo;

public:
	Service(Repo& _repo) : repo{ _repo } {};
	~Service() {};

	vector<Domain> getElements() const;
	vector<Domain> filterElements(const string& category) const;
	void removeElement(const Domain& element);
	void addElement(const string& description, int duration, int priority);
	void updateElement(const string& description, int duration, int priority);

};

