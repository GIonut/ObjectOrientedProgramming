#include "TaskManager.h"
#include <QtWidgets/QApplication>

#include "Service.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Repo repo{ "TaskManager.txt" };
    Service service{ repo };
    TaskManager w{ service };
    w.show();
    return a.exec();
}
