#pragma once
#include "Service.h"
#include <QtWidgets/QMainWindow>
#include "ui_TaskManager.h"
#include <algorithm>
class TaskManager : public QMainWindow
{
    Q_OBJECT

public:
    TaskManager(Service& service, QWidget *parent = Q_NULLPTR);

private:
    Ui::TaskManagerClass ui;
    Service& service;
	void populateList();
	void connectSignalsAndSlots();
	int getSelectedIndex() const;

public slots:
	void removeFromList();
	//void filterList();
	void updateList();
	void addToList();
	void ShowBolded();
	void showDuration();
};
