#include "TaskManager.h"

TaskManager::TaskManager(Service& _service, QWidget* parent)
    : QMainWindow(parent), service{ _service }
{
    ui.setupUi(this);
    this->populateList();
    this->connectSignalsAndSlots();
}

void TaskManager::populateList()
{
    this->ui.elementsListWidget->clear();

    vector<Domain> elements = this->service.getElements();

    sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getPriority() < j.getPriority(); });

    for (const Domain& element : elements)
    {
        this->ui.elementsListWidget->addItem(QString::fromStdString(element.getDescription()) + " | " + QString::fromStdString(to_string(element.getDuration())) + " | " + QString::fromStdString(to_string(element.getPriority())));
    }
}

void TaskManager::showDuration()
{
    string priority = this->ui.lineEdit_4->text().toStdString();

    vector<Domain> elements = service.getElements();

    int totalDuration = 0;

    for (const Domain& element : elements)
    {
        if (element.getPriority() == stoi(priority))
        {
            totalDuration += element.getDuration();
        }
    }

    this->ui.lineEdit_5->setText(QString::fromStdString(to_string(totalDuration)));
}

void TaskManager::ShowBolded()
{
    this->ui.elementsListWidget->clear();
    vector<Domain> elements = this->service.getElements();
    vector<QListWidgetItem*> pointers;
    for (const Domain& element : elements)
    {
        if (element.getPriority() == 1)
        {
            QListWidgetItem* item = new QListWidgetItem;
            pointers.push_back(item);
            item->setText((QString::fromStdString(element.getDescription()) + " | " + \
                QString::fromStdString(to_string(element.getDuration())) + " | " + \
                QString::fromStdString(to_string(element.getPriority()))));

             QFont font("Times", 10, QFont::Bold);
             item->setFont(font);
             this->ui.elementsListWidget->addItem(item);
        }
        else
            this->ui.elementsListWidget->addItem(QString::fromStdString(element.getDescription()) + " | " + QString::fromStdString(to_string(element.getDuration())) + " | " + QString::fromStdString(to_string(element.getPriority())));
    }

    for (int i = 0; i < pointers.size(); i++)
    {
        //delete pointers[i];
    }
}

void TaskManager::updateList()
{
    string description = this->ui.lineEdit_1->text().toStdString();
    string duration = this->ui.lineEdit_2->text().toStdString();
    string priority = this->ui.lineEdit_3->text().toStdString();

    this->service.updateElement(description, stoi(duration), stoi(priority));

    this->populateList();
}

void TaskManager::addToList()
{
    string description = this->ui.lineEdit_1->text().toStdString();
    string duration = this->ui.lineEdit_2->text().toStdString();
    string priority = this->ui.lineEdit_3->text().toStdString();

    this->service.addElement(description, stoi(duration), stoi(priority));

    this->populateList();
}

void TaskManager::removeFromList()
{
    QModelIndexList selectedIndexes = this->ui.elementsListWidget->selectionModel()->selectedIndexes();
    int selectedIndex = selectedIndexes.at(0).row();

    vector<Domain> elements = this->service.getElements();
    sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getPriority() < j.getPriority(); });

    Domain element = elements[selectedIndex];
    this->service.removeElement(element);

    this->populateList();
}

void TaskManager::connectSignalsAndSlots()
{
    QObject::connect(this->ui.elementsListWidget, &QListWidget::itemSelectionChanged, [this] {

        int selectedIndex = this->getSelectedIndex();

        if (selectedIndex < 0)
            return;

        vector<Domain> elements = this->service.getElements();
        sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getPriority() < j.getPriority(); });

        Domain element = elements[selectedIndex];

        this->ui.lineEdit_1->setText(QString::fromStdString(element.getDescription()));
        this->ui.lineEdit_2->setText(QString::fromStdString(to_string(element.getDuration())));
        this->ui.lineEdit_3->setText(QString::fromStdString(to_string(element.getPriority())));

        });

}

int TaskManager::getSelectedIndex() const
{
    QModelIndexList selectedIndexes = this->ui.elementsListWidget->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        this->ui.lineEdit_1->clear();
        this->ui.lineEdit_2->clear();
        this->ui.lineEdit_3->clear();
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}