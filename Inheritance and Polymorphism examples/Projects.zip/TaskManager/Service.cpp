#include "Service.h"

vector<Domain> Service::getElements() const
{
	return this->repo.get();
}

vector<Domain> Service::filterElements(const string& category) const
{
	if (category == "")
		return this->repo.get();

	vector<Domain> elements = this->repo.get();
	vector<Domain> filteredElements;

	for (const Domain& element : elements)
	{
		if (element.getDescription() == category)
			filteredElements.push_back(element);
	}

	return filteredElements;
}

void Service::removeElement(const Domain& element)
{
	this->repo.remove(element);
}

void Service::addElement(const string& description, int duration, int priority)
{
	Domain element{ description, duration, priority };

	this->repo.add(element);
}

void Service::updateElement(const string& description, int duration, int priority)
{
	Domain element{ description, duration, priority };

	this->repo.update(element);
}
