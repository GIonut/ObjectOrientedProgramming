#include "Service.h"

vector<Domain> Service::getElements() const
{
	return this->repo.get();
}

vector<Domain> Service::filterElements(const string& category) const
{
	if (category == "")
		return this->repo.get();

	vector<Domain> elements = this->repo.get();
	vector<Domain> filteredElements;

	for (const Domain& element : elements)
	{
		if (element.getCategory() == category)
			filteredElements.push_back(element);
	}

	return filteredElements;
}

void Service::removeElement(const Domain& element)
{
	this->repo.remove(element);
}

void Service::addElement(const string& category, const string& name, int quantity)
{
	Domain element{ category, name, quantity };

	this->repo.add(element);
}

void Service::updateElement(const string& category, const string& name, int quantity)
{
	Domain element{ category, name, quantity };

	this->repo.update(element);
}
