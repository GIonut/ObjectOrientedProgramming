#include "Emillyshoppinglist.h"
#include <QModelIndex>

Emillyshoppinglist::Emillyshoppinglist(Service& _service,QWidget *parent) : QMainWindow(parent), service{ _service }
{
    ui.setupUi(this);
    this->populateList();
}

void Emillyshoppinglist::populateList()
{
    this->ui.elementsListWidget->clear();

    vector<Domain> elements = this->service.getElements();

    for (const Domain& element : elements)
    {
        this->ui.elementsListWidget->addItem(QString::fromStdString(element.getCategory()) + "|" + QString::fromStdString(element.getName()) + "|" + QString::fromStdString(to_string(element.getQuantity())));
    }
}

void Emillyshoppinglist::filterList()
{
    this->ui.elementsListWidget->clear();

    string category = this->ui.categoryLineEdit->text().toStdString();

    vector<Domain> elements = this->service.filterElements(category);

    for (const Domain& element : elements)
    {
        this->ui.elementsListWidget->addItem(QString::fromStdString(element.getCategory()) + "|" + QString::fromStdString(element.getName()) + "|" + QString::fromStdString(to_string(element.getQuantity())));
    }

}

void Emillyshoppinglist::updateList()
{
    string category = this->ui.addCategoryLineEdit->text().toStdString();
    string name = this->ui.addNameLineEdit->text().toStdString();
    string quantity = this->ui.addQuantityLineEdit->text().toStdString();

    this->service.updateElement(category, name, stoi(quantity));

    this->populateList();
}

void Emillyshoppinglist::addToList()
{
   string category = this->ui.addCategoryLineEdit->text().toStdString();
   string name = this->ui.addNameLineEdit->text().toStdString();
   string quantity = this->ui.addQuantityLineEdit->text().toStdString();

   this->service.addElement(category, name, stoi(quantity));

   this->populateList();
}

void Emillyshoppinglist::removeFromList()
{
    QModelIndexList selectedIndexes = this->ui.elementsListWidget->selectionModel()->selectedIndexes();
    int selectedIndex = selectedIndexes.at(0).row();

    Domain element = this->service.getElements()[selectedIndex];
    this->service.removeElement(element);

    this->populateList();
}