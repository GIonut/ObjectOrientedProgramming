#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Emillyshoppinglist.h"

#include "Service.h"

class Emillyshoppinglist : public QMainWindow
{
    Q_OBJECT

public:
    Emillyshoppinglist(Service& _service, QWidget *parent = Q_NULLPTR);

private:
    Ui::EmillyshoppinglistClass ui;
    Service& service;
    void populateList();

public slots:
    void removeFromList();
    void filterList();
    void updateList();
    void addToList();
};
