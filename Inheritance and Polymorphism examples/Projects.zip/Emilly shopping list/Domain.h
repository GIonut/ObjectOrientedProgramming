#pragma once
#include <string>
#include <vector>

using namespace std;

class Domain
{
private:
	string category{};
	string name{};
	int quantity{};

public:
	Domain() {};
	Domain(string _category, string _name, int _quantity) : category{ _category }, name{ _name }, quantity{ _quantity } {};
	~Domain() {};

	const string& getCategory() const;
	const string& getName() const;
	int getQuantity() const;

	friend istream& operator>>(istream& stream, Domain& element);
	friend ostream& operator<<(ostream& stream, const Domain& element);

	bool operator==(const Domain& element) const;
};

