#include "Emillyshoppinglist.h"
#include <QtWidgets/QApplication>

#include "Service.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   
    Repo repo{ "ShoppingList.txt" };
    Service service{ repo };

    Emillyshoppinglist w{ service };
    w.show();

    return a.exec();
}
