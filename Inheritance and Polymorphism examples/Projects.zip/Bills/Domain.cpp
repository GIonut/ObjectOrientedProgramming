#include "Domain.h"
#include <istream>

const string& Domain::getCompany() const
{
	return this->company;
}

const string& Domain::getCode() const
{
	return this->code;
}

double Domain::getSum() const
{
	return this->sum;
}

bool Domain::getIsPaid() const
{
	return this->isPaid;
}

bool Domain::operator==(const Domain& element) const
{
	return this->code == element.code;
}

istream& operator>>(istream& stream, Domain& element)
{
	string line{};
	getline(stream, line);

	if (line.size() == 0)
		return stream;

	string attributes[4];
	int i = 0;
	int j = 0;
	while (j < line.size())
	{
		if (line[j] == ';')
		{
			i++;
		}
		else {
			attributes[i] += line[j];
		}
		j++;
	}

	element.company = attributes[0];
	element.code = attributes[1];
	element.sum = stod(attributes[2]);

	if (attributes[3] == "true")
		element.isPaid = true;
	else
		element.isPaid = false;

	return stream;
}

ostream& operator<<(ostream& stream, const Domain& element)
{
	const string delimitator = "|";

	stream << element.company << delimitator << element.code << delimitator << element.sum << element.isPaid << static_cast<string>("\n");

	return stream;
}
