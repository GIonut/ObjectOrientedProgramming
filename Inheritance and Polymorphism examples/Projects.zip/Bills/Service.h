#pragma once
#include "Repo.h"


class Service
{
private:
	Repo& repo;

public:
	Service(Repo& _repo) : repo{ _repo } {};
	~Service() {};

	vector<Domain> getElements() const;
	vector<Domain> filterElements(const string& company) const;
	void removeElement(const Domain& element);
	void addElement(string _company, string _code, double _sum, bool _isPaid);
	void updateElement(string _company, string _code, double _sum, bool _isPaid);

};

