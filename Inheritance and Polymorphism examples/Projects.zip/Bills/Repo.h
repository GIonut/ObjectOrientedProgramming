#pragma once
#include <string>
#include <vector>

#include "Domain.h"

using namespace std;

class Repo
{
private:
	string filename{};

public:
	Repo(const string& _filename) : filename{ _filename } {};
	~Repo() {};

	vector<Domain> get() const;
	void remove(const Domain& element);
	void add(Domain element);
	void update(Domain element);

};

