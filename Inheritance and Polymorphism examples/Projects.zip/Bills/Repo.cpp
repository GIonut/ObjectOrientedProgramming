#include "Repo.h"
#include <fstream>
#include <iterator>

vector<Domain> loadFromFile(const string& filename)
{
	ifstream file(filename);
	vector<Domain> elements;

	Domain element{};

	while (file >> element)
	{
		elements.push_back(element);
	}

	return elements;
}

void saveDataToFile(const string& filename, const vector<Domain>& elements)
{
	ofstream file{ filename };

	for (const Domain& element : elements)
	{
		file << element;
	}
}

vector<Domain> Repo::get() const
{
	vector<Domain> elements = loadFromFile(this->filename);
	return elements;
}

void Repo::remove(const Domain& element)
{
	vector<Domain> elements = loadFromFile(this->filename);

	vector<Domain>::iterator it = find(elements.begin(), elements.end(), element);

	if (it != elements.end())
	{
		elements.erase(it);
	}

	saveDataToFile(filename, elements);
}

void Repo::add(Domain element)
{
	vector<Domain> elements = loadFromFile(this->filename);

	elements.push_back(element);

	saveDataToFile(this->filename, elements);
}

void Repo::update(Domain element)
{
	vector<Domain> elements = loadFromFile(this->filename);

	vector<Domain>::iterator it = find(elements.begin(), elements.end(), element);

	if (it != elements.end())
	{
		elements.erase(it);
		elements.push_back(element);
	}

	saveDataToFile(this->filename, elements);
}
