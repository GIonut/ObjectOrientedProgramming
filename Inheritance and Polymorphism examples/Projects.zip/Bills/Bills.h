#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Bills.h"

#include"Service.h"

class Bills : public QMainWindow
{
    Q_OBJECT

public:
    Bills(Service& service, QWidget *parent = Q_NULLPTR);

private:
    Ui::BillsClass ui;
    Service& service;

    void populateList();
    void connectSignalsAndSlots();
    int getSelectedIndex() const;

public slots:
    void sortList();
    void showTotal();
};
