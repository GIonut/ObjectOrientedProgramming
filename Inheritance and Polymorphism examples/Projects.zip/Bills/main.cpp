#include "Bills.h"
#include <QtWidgets/QApplication>

#include "Service.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Repo repo{ "Bills.txt" };
    Service service{ repo };

    Bills w{ service };
    w.show();

    return a.exec();
}
