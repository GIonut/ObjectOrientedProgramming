#pragma once
#pragma once
#include <string>
#include <vector>

using namespace std;

class Domain
{
private:
	string company{};
	string code{};
	double sum{};
	bool isPaid{};

public:
	Domain() {};
	Domain(string _company, string _code, double _sum, bool _isPaid) : company{ _company }, code{ _code }, sum{ _sum }, isPaid{ _isPaid } {};
	~Domain() {};

	const string& getCompany() const;
	const string& getCode() const;
	double getSum() const;
	bool getIsPaid() const;

	friend istream& operator>>(istream& stream, Domain& element);
	friend ostream& operator<<(ostream& stream, const Domain& element);

	bool operator==(const Domain& element) const;
};
