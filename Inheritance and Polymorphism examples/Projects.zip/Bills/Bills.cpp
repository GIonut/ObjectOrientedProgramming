#include "Bills.h"

Bills::Bills(Service& service, QWidget *parent): QMainWindow(parent), service{ service }
{
    ui.setupUi(this);
    this->populateList();
    this->connectSignalsAndSlots();
}


void Bills::populateList()
{
    this->ui.elementsListWidget->clear();

    vector<Domain> elements = this->service.getElements();

    //sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getPriority() < j.getPriority(); });

    for (const Domain& element : elements)
    {
        this->ui.elementsListWidget->addItem(QString::fromStdString(element.getCompany()) + "; " \
            + QString::fromStdString(element.getCode()) + "; "\
            + QString::fromStdString(to_string(element.getSum())) + "; " \
            + QString::fromStdString(to_string(element.getIsPaid())));
    }
}

void Bills::connectSignalsAndSlots()
{
    QObject::connect(this->ui.elementsListWidget, &QListWidget::itemSelectionChanged, [this] {

        int selectedIndex = this->getSelectedIndex();

        if (selectedIndex < 0)
            return;

        vector<Domain> elements = this->service.getElements();
        //sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getPriority() < j.getPriority(); });

        Domain element = elements[selectedIndex];

        this->ui.lineEdit_1->setText(QString::fromStdString(element.getCompany()));
        this->ui.lineEdit_2->setText(QString::fromStdString(element.getCode()));
        this->ui.lineEdit_3->setText(QString::fromStdString(to_string(element.getSum())));
        this->ui.lineEdit_4->setText(QString::fromStdString(to_string(element.getIsPaid())));

        });

}

int Bills::getSelectedIndex() const
{
    QModelIndexList selectedIndexes = this->ui.elementsListWidget->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        this->ui.lineEdit_1->clear();
        this->ui.lineEdit_2->clear();
        this->ui.lineEdit_3->clear();
        this->ui.lineEdit_4->clear();
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}

void Bills::showTotal()
{
    string company = this->ui.lineEdit_5->text().toStdString();

    vector<Domain> elements = this->service.getElements();

    double totalSum = 0;

    for (const Domain& element : elements)
    {
        if (element.getCompany() == company && element.getIsPaid() == false)
            totalSum += element.getSum();
    }

    this->ui.label->setText(QString::fromStdString(to_string(totalSum)));
}

void Bills::sortList()
{
    this->ui.elementsListWidget->clear();

    vector<Domain> elements = this->service.getElements();

    sort(elements.begin(), elements.end(), [&](const Domain& i, const Domain& j) {return i.getCompany() < j.getCompany(); });

    for (const Domain& element : elements)
    {
        this->ui.elementsListWidget->addItem(QString::fromStdString(element.getCompany()) + "; " \
            + QString::fromStdString(element.getCode()) + "; "\
            + QString::fromStdString(to_string(element.getSum())) + "; " \
            + QString::fromStdString(to_string(element.getIsPaid())));
    }
}