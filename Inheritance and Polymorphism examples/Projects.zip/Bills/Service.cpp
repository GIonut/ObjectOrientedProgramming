#include "Service.h"

vector<Domain> Service::getElements() const
{
	return this->repo.get();
}

vector<Domain> Service::filterElements(const string& company) const
{
	if (company == "")
		return this->repo.get();

	vector<Domain> elements = this->repo.get();
	vector<Domain> filteredElements;

	for (const Domain& element : elements)
	{
		if (element.getCompany() == company)
			filteredElements.push_back(element);
	}

	return filteredElements;
}

void Service::removeElement(const Domain& element)
{
	this->repo.remove(element);
}

void Service::addElement(string _company, string _code, double _sum, bool _isPaid)
{
	Domain element{ _company, _code, _sum, _isPaid };

	this->repo.add(element);
}

void Service::updateElement(string _company, string _code, double _sum, bool _isPaid)
{
	Domain element{ _company, _code, _sum, _isPaid };

	this->repo.update(element);
}
