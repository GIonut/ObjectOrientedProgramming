#include "Model.h"

int Model::rowCount(const QModelIndex& parent) const
{
	return this->elements.size();
}

QVariant Model::data(const QModelIndex& index, int role) const
{
	int row = index.row();
	if (role == Qt::DisplayRole)
	{
		return QString::fromStdString(this->elements[row].toString());
	}
	return QVariant();
}

void Model::reset()
{
	this->elements = this->service.filter(this->class1);
	emit layoutChanged();
}
