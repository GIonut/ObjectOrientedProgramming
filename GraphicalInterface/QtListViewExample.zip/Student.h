#pragma once

#include <QWidget>
#include "ui_Student.h"
#include "Domain.h"
#include "Service.h"
#include "Model.h"

class Student : public QWidget
{
	Q_OBJECT

public:
	Student(Service& _service, Class2 _class2, Model* _model, QWidget *parent = Q_NULLPTR);
	~Student();

private:
	Ui::Student ui;
	Class2 class2;
	Service& service;
	Model* model;

	void populate();

public slots:
	void save();
	void cancel();
};
