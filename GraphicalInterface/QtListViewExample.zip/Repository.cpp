#include "Repository.h"
#include <fstream>

Repository::Repository(string _file1, string _file2) : file1(_file1), file2(_file2)
{
	ifstream fin1(file1);
	Class1 class1;
	while (fin1 >> class1)
		classes1.push_back(class1);
	fin1.close();

	ifstream fin2(file2);
	Class2 class2;
	while (fin2 >> class2)
		classes2.push_back(class2);
	fin2.close();
}

Repository::~Repository()
{
	ofstream fout(file2);
	for (auto class2 : classes2)
		fout << class2 << "\n";
	fout.close();
}

void Repository::add(Class2 class2)
{
	classes2.push_back(class2);
}
