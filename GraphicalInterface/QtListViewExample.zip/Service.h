#pragma once
#include "Repository.h"
#include "Observer.h"

class Service
{
public:
	Repository& repo;
	Service(Repository& _repo) : repo(_repo) {};
	void add(string _attribute1, string _attribute2, string _attribute3, string _attribute4, string _attribute5, string _attribute6);
	vector<Class2> filter(Class1 class1);
	vector<Class2> filterText(string text);
	void addCoordinator(Class1 class1, Class2 class2);
	void update(Class2 class2, string email, string title);
};

