#include "GUI.h"
#include "Student.h"

GUI::GUI(Service& _service, Class1 _class1, Model* _model, QWidget* parent)
    : QMainWindow(parent), service(_service), class1(_class1), model(_model)
{
    ui.setupUi(this);
    this->setWindowTitle(QString::fromStdString(_class1.attribute1));
    this->ui.listView->setModel(_model);
    this->chartView = new QChartView();
}

void GUI::fillList(QString text)
{
    this->ui.listWidget->clear();

    this->elements = this->service.filterText(text.toStdString());
    for (auto element : elements)
        this->ui.listWidget->addItem(QString::fromStdString(element.toString()));
}

int GUI::getSelectedIndex(QListView* list)
{
    QModelIndexList allIndexes = list->selectionModel()->selectedIndexes();
    if (allIndexes.size() < 0)
        return -1;
    int selectedIndex = allIndexes.at(0).row();
    return selectedIndex;
}

void GUI::check()
{
    int index = this->getSelectedIndex(this->ui.listWidget);
    if (this->elements[index].attribute6 != "")
        this->ui.pushButton->setDisabled(true);
    else
        this->ui.pushButton->setDisabled(false);
    
}

void GUI::add()
{
    int index = this->getSelectedIndex(this->ui.listWidget);
    this->service.addCoordinator(this->class1, this->elements[index]);
    this->model->reset();
    this->chart();
}

void GUI::open()
{
    int index = this->getSelectedIndex(this->ui.listView);
    auto elements = this->service.filter(this->class1);
    Student* student = new Student(this->service, elements[index], this->model);
    student->show();
}

void GUI::chart()
{
    QBarSet* sets = new QBarSet("ABC");
    auto elements = this->service.repo.classes1;
    QBarSeries* series = new QBarSeries();

    for (auto element : elements)
    {
        sets = new QBarSet(QString::fromStdString(element.attribute1));
        *sets << this->service.filter(element).size();
        series->append(sets);
    }
    Class1 empty;
    sets = new QBarSet(QString::fromStdString("NoCoord"));
    *sets << this->service.filter(empty).size();
    series->append(sets);

    QChart* chart = new QChart();
    chart->addSeries(series);

    QStringList categories;
    categories << "Students";

    QBarCategoryAxis* axis = new QBarCategoryAxis();
    axis->append(categories);
    chart->createDefaultAxes();
    chart->setAxisX(axis, series);
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);

    chartView->setChart(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    QPalette palette = qApp->palette();
    palette.setColor(QPalette::Window, QRgb(0xffffff));
    palette.setColor(QPalette::WindowText, QRgb(0x404040));
    qApp->setPalette(palette);
    chartView->show();
   }