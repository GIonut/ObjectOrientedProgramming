#include "Service.h"
#include<algorithm>
void Service::add(string _attribute1, string _attribute2, string _attribute3, string _attribute4, string _attribute5, string _attribute6)
{
}

vector<Class2> Service::filter(Class1 class1)
{
	vector<Class2> elements;
	vector<Class2> ordered;
	for (auto class2 : this->repo.classes2)
	{
		if (class2.attribute6 == class1.attribute1)
		{
			if (class2.attribute4 == "2020")
				elements.push_back(class2);
			else
				ordered.push_back(class2);
		}
	}
	sort(ordered.begin(), ordered.end(), [](auto i, auto j) { return i.attribute4 > j.attribute4; });
	
	for (auto class2 : ordered)
		elements.push_back(class2);

	return elements;
}

vector<Class2> Service::filterText(string text)
{
	vector<Class2> elements;
	for (auto class2 : this->repo.classes2)
	{
		if (class2.attribute1.find(text) != string::npos || class2.attribute2.find(text) != string::npos)
			elements.push_back(class2);
	}
	return elements;
}

void Service::addCoordinator(Class1 class1, Class2 class2)
{
	for (Class2& element : this->repo.classes2)
	{
		if (class2.attribute1 == element.attribute1)
		{
			element.attribute6 = class1.attribute1;
			return;
		}
	}
}

void Service::update(Class2 class2, string email, string title)
{
	for(Class2& element : this->repo.classes2)
		if (element.attribute1 == class2.attribute1)
		{
			element.attribute3 = email;
			element.attribute5 = title;
			return;
		}
}
