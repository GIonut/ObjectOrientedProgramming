#include "GUI.h"
#include <QtWidgets/QApplication>
#include "Service.h"
#include "Model.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Repository repo("teachers.txt", "students.txt");
    Service service(repo);
    for (auto class1 : repo.classes1)
    {
        Model* model = new Model(service, class1);
        GUI* w = new GUI(service, class1, model);
        w->show();
    }
    return a.exec();
}
