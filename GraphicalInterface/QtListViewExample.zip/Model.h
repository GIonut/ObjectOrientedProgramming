#pragma once
#include "Domain.h"
#include "Service.h"
#include <QAbstractItemModel>

class Model : public QAbstractListModel
{
private:
	Class1 class1;
	Service& service;
	vector<Class2> elements;
public:
	Model(Service& _service, Class1 _class1, QObject* parent = nullptr) : service(_service), class1(_class1) 
	{ 
		this->elements = this->service.filter(_class1); 
	};
	
	int rowCount(const QModelIndex& parent = QModelIndex()) const;
	QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const;
	void reset();

};

