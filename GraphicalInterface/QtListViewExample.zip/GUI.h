#pragma once

#include <QtWidgets/QMainWindow>
#include "Service.h"
#include "Model.h"
#include "ui_GUI.h"
#include "Observer.h"

#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <qchart.h>

QT_CHARTS_USE_NAMESPACE;


class GUI : public QMainWindow
{
    Q_OBJECT

public:
    GUI(Service& _service, Class1 _class1, Model* _model, QWidget *parent = Q_NULLPTR);

private:
    Ui::GUIClass ui;
    Service& service;
    Model* model;
    Class1 class1;
    QChartView* chartView;
    vector<Class2> elements;

    int getSelectedIndex(QListView* list);

public slots:
    void fillList(QString text);
    void check();
    void add();
    void open();
    void chart();
};
