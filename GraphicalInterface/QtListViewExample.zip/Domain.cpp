#include "Domain.h"
#include <sstream>

istream& operator>>(istream& reader, Class1& class1)
{
	string line;
	getline(reader, line);
	stringstream ss(line);
	string attribute1;
	getline(ss, attribute1, ';');
	class1.attribute1 = attribute1;
	return reader;
}

istream& operator>>(istream& reader, Class2& class2)
{
	string line;
	getline(reader, line);
	stringstream ss(line);
	string attribute1;
	getline(ss, attribute1, ';');
	class2.attribute1 = attribute1;
	string attribute2;
	getline(ss, attribute2, ';');
	class2.attribute2 = attribute2;
	string attribute3;
	getline(ss, attribute3, ';');
	class2.attribute3 = attribute3;
	string attribute4;
	getline(ss, attribute4, ';');
	class2.attribute4 = attribute4;
	string attribute5;
	getline(ss, attribute5, ';');
	class2.attribute5 = attribute5;
	string attribute6;
	getline(ss, attribute6, ';');
	class2.attribute6 = attribute6;
	
	return reader;
}

ostream& operator<<(ostream& writer, Class2& class2)
{
	writer << class2.attribute1 << ";" << class2.attribute2 << ";" << class2.attribute3 << ";" << class2.attribute4 << ";" << class2.attribute5 << ";" << class2.attribute6;
	return writer;
}

Class2::Class2(string _attribute1, string _attribute2, string _attribute3, string _attribute4, string _attribute5, string _attribute6)
{
	this->attribute1 = _attribute1;
	this->attribute2 = _attribute2;
	this->attribute3 = _attribute3;
	this->attribute4 = _attribute4;
	this->attribute5 = _attribute5;
	this->attribute6 = _attribute6;

}

string Class2::toString() const
{
	return  attribute1 + ";" + attribute2 + ";" + attribute3 + ";" + attribute4 + ";" + attribute5 + ";" + attribute6;
}
