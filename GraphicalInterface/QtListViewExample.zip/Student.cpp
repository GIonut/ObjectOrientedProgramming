#include "Student.h"
#include <qmessagebox.h>
Student::Student(Service& _service, Class2 _class2, Model* _model, QWidget *parent)
	: QWidget(parent), class2(_class2), service(_service), model(_model)
{
	ui.setupUi(this);
	this->setWindowTitle(QString::fromStdString(class2.attribute2));
	this->populate();
}

Student::~Student()
{
}

void Student::populate()
{
	this->ui.lineEdit->setText(QString::fromStdString(class2.attribute1));
	this->ui.lineEdit_2->setText(QString::fromStdString(class2.attribute2));
	this->ui.lineEdit_3->setText(QString::fromStdString(class2.attribute3));
	this->ui.lineEdit_4->setText(QString::fromStdString(class2.attribute4));
	this->ui.lineEdit_5->setText(QString::fromStdString(class2.attribute5));
	this->ui.lineEdit_6->setText(QString::fromStdString(class2.attribute6));
}

void Student::cancel()
{
	this->close();
}

void Student::save()
{
	string email = this->ui.lineEdit_3->text().toStdString();
	string title = this->ui.lineEdit_5->text().toStdString();
	this->service.update(class2, email, title);
	QMessageBox::information(this, "Info", "Modifications Saved!");
	this->model->reset();
}