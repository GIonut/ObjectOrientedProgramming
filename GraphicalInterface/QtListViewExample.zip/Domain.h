#pragma once
#include <string>
#include <iostream>

using namespace std;

class Class1
{
public:
	string attribute1;
	friend istream& operator>>(istream& reader, Class1& class1);
};


class Class2
{
public:
	string attribute1;
	string attribute2;
	string attribute3;
	string attribute4;
	string attribute5;
	string attribute6;

	Class2() {};
	Class2(string _attribute1, string _attribute2, string _attribute3, string _attribute4, string _attribute5, string _attribute6);
	friend istream& operator>>(istream& reader, Class2& class2);
	friend ostream& operator<<(ostream& writer, Class2& class2);
	string toString() const;
};

