#pragma once
#include "Domain.h"
#include <vector>
#include <algorithm>
#include "Observer.h"
using namespace std;

class Service: public Subject
{
	string file1, file2;
public:
	vector<Class1> classes1;
	vector<Class2> classes2;
	Service() {};
	Service(string file1, string file2);
	~Service();
	vector<Class2> filter();

	//function that adds a class2 to classes2 vector, given all the attributes needed as parameters; 
	//if the parameters are invalid(attribute1 is empty, attribute 4 different from 1, 2, or 3, throw std::exception
	//input:string	_attribute1, _attribute2, _attribute3
	//		int _attribute4
	//output: nothing, throw exception if the parameteres are invalid, an object of type Class2 was added to classes2 vector
	void add(string _attribute1, string _attribute2, string _attribute3, int _attribute4);
	
	//function that changes the status of a class2 object given as parameter from proposed to accepted
	//input: Class2 class2
	//output: nothing, the status of the class2 object in the classes2 having attribute1 being equal to attribute1 of the Class2 object
	//given as parameter
	void revise(Class2 class2);

	vector<Class2> getAccepted(Class1 class1);
};

