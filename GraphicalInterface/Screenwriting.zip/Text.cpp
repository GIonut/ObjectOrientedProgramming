#include "Text.h"
#include <fstream>
#include <qmessagebox.h>

Text::Text(Class2 class2, QWidget *parent)
	: QWidget(parent), class2(class2)
{
	ui.setupUi(this);
	this->fileName = class2.attribute1 + ".txt";
	this->setWindowTitle(QString::fromStdString(class2.attribute1 + " - Act " + to_string(class2.attribute4)));
	this->populate();
}

void Text::populate()
{
	ifstream fin(this->fileName);
	string text;
	while (getline(fin, text))
		this->ui.textEdit->append(QString::fromStdString(text));
	fin.close();
}

void Text::save()
{
	ofstream fout(fileName);
	string text = this->ui.textEdit->toPlainText().toStdString();
	fout << text;
	fout.close();
	QMessageBox::information(this, "Info", "Saved");
}

Text::~Text()
{
}
