#include "GUI.h"
#include <qmessagebox.h>
#include <qtextedit.h>
#include "Text.h"
#include <fstream>

GUI::GUI(Service& _service, Class1 _class1, Model* _model, QWidget *parent)
    : QMainWindow(parent), service(_service), class1(_class1), model(_model)
{
    ui.setupUi(this);
    this->setWindowTitle(QString::fromStdString(_class1.attribute1 + "-" + _class1.attribute2 + " writer"));
    if (_class1.attribute2 != "Senior")
        this->ui.pushButton_2->setDisabled(true);

    if (this->service.getAccepted(this->class1).empty())
        this->ui.pushButton_3->setDisabled(true);
    else
        this->ui.pushButton_3->setDisabled(false);

    ui.tableView->setModel(model);
    ui.tableView->resizeColumnsToContents();
    ui.tableView->resizeRowsToContents();
    ui.tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void GUI::update()
{
    if (this->service.getAccepted(this->class1).empty())
        this->ui.pushButton_3->setDisabled(true);
    else
        this->ui.pushButton_3->setDisabled(false);
    this->model->adding();
}

void GUI::add()
{
    string attribute1 = this->ui.lineEdit_2->text().toStdString();
    string attribute2 = "proposed";
    string attribute3 = this->class1.attribute1;
    string attribute4 = this->ui.lineEdit->text().toStdString();

    try
    {
        this->service.add(attribute1, attribute2, attribute3, stoi(attribute4));
    }
    catch (exception& e)
    {
        QMessageBox::critical(this, "Error", e.what());
        return;
    }

    this->update();
}

int GUI::getSelectedIndex()
{
    QModelIndexList selectedIndexes = this->ui.tableView->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}


void GUI::revise()
{
    int index = this->getSelectedIndex();
    auto elements = this->service.filter();
    this->service.revise(elements[index]);
}

void GUI::selection()
{
    int index = this->getSelectedIndex();
    Class2 class2 = this->service.filter()[index];
    if (class2.attribute2 != "proposed")
        this->ui.pushButton_2->setDisabled(true);
    else
        this->ui.pushButton_2->setDisabled(false);
}

void GUI::develop()
{
    auto ideas = this->service.getAccepted(this->class1);
    for (auto idea : ideas)
    {
        Text* text = new Text{ idea };
        text->show();
    }
}

void GUI::savePlot()
{
    ofstream fin("plot.txt");
    string act1, act2, act3;
   
    for (auto class2 : this->service.classes2)
    {
        if (class2.attribute2 == "accepted")
        {
            string text;
            if (class2.attribute4 == 1)
            {
                act1 += class2.attribute1 + "(" + class2.attribute3 + ")\n";
                ifstream fin1(class2.attribute1 + ".txt");
                while (getline(fin1, text))
                {
                    act1 += text + "\n";
                }
            }
            else if (class2.attribute4 == 2)
            {
                act2 += class2.attribute1 + "(" + class2.attribute3 + ")\n";
                ifstream fin1(class2.attribute1 + ".txt");
                while (getline(fin1, text))
                {
                    act2 += text + "\n";
                }
            }
            else
            {
                act3 += class2.attribute1 + "(" + class2.attribute3 + ")\n";
                ifstream fin1(class2.attribute1 + ".txt");
                while (getline(fin1, text))
                {
                    act3 += text + "\n";
                }
            }
        }
    }

    
    fin << "Act 1\n" << act1 << "\nAct 2\n" << act2 << "\nAct 3\n" << act3;
    QMessageBox::information(this, "info", "Plot Saved!");
    system("start notepad plot.txt");
}