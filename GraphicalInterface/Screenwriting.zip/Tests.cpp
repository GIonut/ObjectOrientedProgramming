#include "Tests.h"
#include <assert.h>

void Tests::test()
{
	FakeRepo repo;
	assert(repo.classes2.empty());
	repo.add("a", "proposed", "a", 1);
	try
	{
		repo.add("", "proposed", "a", 1);
		assert(false);
	}
	catch (exception& e)
	{
		assert(true);
	}
	try
	{
		repo.add("a", "proposed", "a", 4);
		assert(false);
	}
	catch (exception& e)
	{
		assert(true);
	}
	assert(repo.classes2.size() == 1);
	assert(repo.classes2[0].attribute2 == "proposed");
	repo.revise(Class2("a", "proposed", "a", 1));
	assert(repo.classes2[0].attribute2 == "accepted");

}
