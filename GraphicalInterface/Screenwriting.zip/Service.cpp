#include "Service.h"
#include <fstream>


Service::Service(string file1, string file2) : file1(file1), file2(file2)
{
	ifstream fin(file1);
	Class1 class1;
	while (fin >> class1)
		this->classes1.push_back(class1);
	fin.close();
	ifstream fin1(file2);
	Class2 class2;
	while (fin1 >> class2)
		this->classes2.push_back(class2);
	fin1.close();

}

Service::~Service()
{
	ofstream fout(this->file2);
	for (auto class2 : classes2)
		fout << class2 << "\n";
	fout.close();
}

vector<Class2> Service::filter()
{
	vector<Class2> elements = classes2;
	sort(elements.begin(), elements.end(), [](auto i, auto j) { return i.attribute4 < j.attribute4; });
	return elements;
}

void Service::add(string _attribute1, string _attribute2, string _attribute3, int _attribute4)
{
	if (_attribute1.empty() || _attribute4 > 3 || _attribute4 <= 0)
		throw exception("Invalid object!");
	for(auto class2 : this->classes2)
	{ 
		if(class2.attribute1 == _attribute1)
			throw exception("Invalid object!");
	}
	Class2 class2(_attribute1, _attribute2, _attribute3, _attribute4);
	this->classes2.push_back(class2);
	this->notify();
}

void Service::revise(Class2 class2)
{
	for (Class2& element : classes2)
	{
		if (element.attribute1 == class2.attribute1)
			element.attribute2 = "accepted";
	}
	this->notify();
}

vector<Class2> Service::getAccepted(Class1 class1)
{
	vector<Class2> elements;
	for (auto element : classes2)
	{
		if (element.attribute2 == "accepted" && element.attribute3 == class1.attribute1)
		{
			elements.push_back(element);
		}
	}
	return elements;
}




