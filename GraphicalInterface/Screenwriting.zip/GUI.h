#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_GUI.h"
#include "Service.h"
#include "Domain.h"
#include "Model.h"
#include "Observer.h"

class GUI : public QMainWindow, public Observer
{
    Q_OBJECT

public:
    GUI(Service& _service, Class1 _class1, Model* _model, QWidget *parent = Q_NULLPTR);

private:
    Ui::GUIClass ui;
    Service& service;
    Class1 class1;
    Model* model;
    void update() override;

    int getSelectedIndex();

public slots:
    void add();
    void revise();
    void selection();
    void develop();
    void savePlot();
};
