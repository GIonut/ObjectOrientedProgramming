#include "Domain.h"
#include <sstream>

istream& operator>>(istream& reader, Class1& class1)
{
	string line;
	getline(reader, line);
	if (line.empty())
		return reader;
	stringstream ss(line);
	getline(ss, class1.attribute1, ';');
	getline(ss, class1.attribute2, ';');
	return reader;
}

ostream& operator<<(ostream& writer, Class2& class2)
{
	writer << class2.attribute1 << ";" << class2.attribute2 << ";" << class2.attribute3 << ";" << class2.attribute4;
	return writer;
}

istream& operator>>(istream& reader, Class2& class2)
{
	string line;
	getline(reader, line);
	if (line.empty())
		return reader;
	stringstream ss(line);
	getline(ss, class2.attribute1, ';');
	getline(ss, class2.attribute2, ';');
	getline(ss, class2.attribute3, ';');
	string attribute4;
	getline(ss, attribute4, ';');
	class2.attribute4 = stoi(attribute4);
	return reader;
}

Class2::Class2(string _attribute1, string _attribute2, string _attribute3, int _attribute4) : attribute1(_attribute1), attribute2(_attribute2), attribute3(_attribute3), attribute4(_attribute4)
{
}

string Class2::toString()
{
	return this->attribute1 + " " + this->attribute2 + " " + this->attribute3 + " " + to_string(this->attribute4);
}
