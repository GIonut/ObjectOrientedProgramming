#pragma once
#include <string>
#include <iostream>
using namespace std;

class Class1
{
public:
	string attribute1;
	string attribute2;
	friend istream& operator>>(istream& reader, Class1& class1);
};

class Class2
{
public:
	string attribute1;
	string attribute2;
	string attribute3;
	int attribute4;
	Class2() {}
	Class2(string _attribute1, string _attribute2, string _attribute3, int _attribute4);
	friend ostream& operator<<(ostream& writer, Class2& class2);
	friend istream& operator>>(istream& reader, Class2& class2);
	string toString();
};

