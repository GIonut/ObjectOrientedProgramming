#pragma once
#include "Service.h"
class Tests
{
public:
	void test();
};

class FakeRepo: public Service
{
public:
	FakeRepo() {};
};
