#include "Model.h"

int Model::rowCount(const QModelIndex& parent) const
{
	return this->elements.size();
}

int Model::columnCount(const QModelIndex& parent) const
{
	return 4;
}

QVariant Model::data(const QModelIndex& index, int role) const
{
	int row = index.row();
	int column = index.column();

	Class2 class2 = this->elements[row];

	if (role == Qt::DisplayRole)
	{
		switch (column)
		{
		case 0:
			return QString::fromStdString(class2.attribute1);
		case 1:
			return QString::fromStdString(class2.attribute2);
		case 2:
			return QString::fromStdString(class2.attribute3);
		case 3:
			return QString::number(class2.attribute4);
		default:
			break;
		}
	}
	return QVariant();
}

QVariant Model::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal)
		{
			switch (section)
			{
			case 0:
				return QString("description");
			case 1:
				return QString("status");
			case 2:
				return QString("creator");
			case 3:
				return QString("act");
			default:
				break;
			}
		}

		if (orientation == Qt::Vertical)
		{
			return section + 1;
		}
	}
	return QVariant();
}

Qt::ItemFlags Model::flags(const QModelIndex& index) const
{
	return Qt::ItemIsSelectable | Qt::ItemIsEnabled;
}

void Model::reset()
{
	this->beginResetModel();
	this->endResetModel();
}

void Model::adding()
{
	this->elements = this->service.filter();
	this->reset();
}
