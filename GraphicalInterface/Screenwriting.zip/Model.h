#pragma once
#include "Service.h"
#include<vector>
#include<string>
#include <qabstractitemmodel.h>

using namespace std;

class Model : public QAbstractTableModel
{
	Service& service;
	Class1 _class1;

public:
	vector<Class2> elements;
	Model(Service& _service, Class1 _class1) : service{ _service } { this->elements = _service.filter(); };
	int rowCount(const QModelIndex& parent = QModelIndex()) const;
	int columnCount(const QModelIndex& parent = QModelIndex()) const;
	QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const;
	QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const;
	Qt::ItemFlags flags(const QModelIndex& index) const;
	void reset();
	void adding();
};

