#pragma once

#include <QWidget>
#include "ui_Text.h"
#include "Domain.h"

class Text : public QWidget
{
	Q_OBJECT

public:
	Text(Class2 class2, QWidget *parent = Q_NULLPTR);
	~Text();

private:
	Ui::Text ui;
	Class2 class2;
	string fileName;

	void populate();

public slots:
	void save();
};
