#include "GUI.h"
#include <QtWidgets/QApplication>
#include "Service.h"
#include "Domain.h"
#include "Model.h"
#include "Observer.h"
#include "Tests.h"
int main(int argc, char* argv[])
{
    QApplication a(argc, argv);
    Tests tests;
    tests.test();
    Service service("screenwriters.txt", "ideas.txt");
    for (auto class1 : service.classes1)
    {
        Model* model = new Model{ service, class1 };
        GUI* w = new GUI{ service, class1, model };
        service.addObserver(w);
        w->show();
    }
    return a.exec();
}
