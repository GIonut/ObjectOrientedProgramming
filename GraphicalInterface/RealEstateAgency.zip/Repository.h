#pragma once
#include "Client.h"
#include "Dwelling.h"
#include <vector>
#include <memory>

class ClientsRepository
{
public:
	ClientsRepository();
	~ClientsRepository();

	vector<shared_ptr<Client>> clients{};

	void remove(const string&);
	vector<shared_ptr<Client>> get() const;
	void write(const string& filename) const;
	void add(shared_ptr<Client> client);

};

class DwellingsRepository
{
private:
	vector<Dwelling> dwellings{};

public:
	DwellingsRepository();
	~DwellingsRepository();

	void add(Dwelling dwelling);
	vector<Dwelling> get() const;

};