#pragma once
#include <string>
using namespace std;

class Dwelling
{
private:
	string type{};
	double price{};
	bool isProfitable{};

public:
	Dwelling(string _type, double _price, bool _isProfitable);
	~Dwelling();

	bool profitableDwelling() const;
	double normalBankRate() const;
	double largeBankRate() const;
	string toString() const;
	string getType() const;
};

