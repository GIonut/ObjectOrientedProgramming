#include "Dwelling.h"
#include <sstream>

Dwelling::Dwelling(string _type, double _price, bool _isProfitable) : type{ _type }, price{ _price }, isProfitable{ _isProfitable }
{
}

Dwelling::~Dwelling()
{
}

bool Dwelling::profitableDwelling() const
{
	if (this->isProfitable)
		return true;
	else
		return false;
}

double Dwelling::normalBankRate() const
{
	return this->price/1000;
}

double Dwelling::largeBankRate() const
{
	return price/100;
}

string Dwelling::toString() const
{
	stringstream stream;
	string booleanValue{};
	if (this->isProfitable == true)
		booleanValue = "true";
	else
		booleanValue = "false";

	stream << this->type << "," << this->price << "," << booleanValue;
	return stream.str();
}

string Dwelling::getType() const
{
	return this->type;
}

