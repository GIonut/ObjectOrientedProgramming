#pragma once
#include "RealEstateAgency.h"

class Ui
{
private:
	RealEstateAgency agency;

public:
	Ui(RealEstateAgency& agency);
	~Ui();

	void ui_run();
	void ui_addDwelling();
	void ui_removeClient();
	void ui_saveClients(string filename);
	void ui_printAll();
	void ui_printInterested(string);

};
