#include "Repository.h"
#include <fstream>

ClientsRepository::ClientsRepository()
{
}

ClientsRepository::~ClientsRepository()
{
}

void ClientsRepository::remove(const string& _name)
{
	for (auto i = clients.begin(); i != clients.end() ; i++)
	{
		if ((*i)->getName() == _name)
		{
			clients.erase(i);
			return;
		}
	}
}

vector<shared_ptr<Client>> ClientsRepository::get() const
{
	return this->clients;
}

void ClientsRepository::write(const string& filename) const
{
	ofstream file(filename);

	for (auto client : clients)
	{
		file << (*client);
	}
}

void ClientsRepository::add(shared_ptr<Client> client)
{
	this->clients.push_back(client);
}

DwellingsRepository::DwellingsRepository()
{
}

DwellingsRepository::~DwellingsRepository()
{
}

void DwellingsRepository::add(Dwelling dwelling)
{
	this->dwellings.push_back(dwelling);
}

vector<Dwelling> DwellingsRepository::get() const
{
	return this->dwellings;
}
