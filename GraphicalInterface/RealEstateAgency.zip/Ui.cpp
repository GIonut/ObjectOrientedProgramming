#include "Ui.h"

Ui::Ui(RealEstateAgency& _agency): agency{_agency}
{
}

Ui::~Ui()
{
}


void Ui::ui_run()
{
	while (true)
	{
		string commandLine;
		cout << "Type a command!\n";
		getline(cin, commandLine);

		string command = commandLine.substr(0, commandLine.find(" "));

		commandLine = commandLine.erase(0, commandLine.find(" ") + 1);

		int begin = 0;
		int end;

		string parameters[10];

		end = commandLine.find(", ");
		int i = 0;
		if (command == "fileLocation")
		{
			parameters[0] = commandLine.substr(0, commandLine.size());
		}
		if(end != -1)
		while (commandLine.size() > 0)
		{
			parameters[i] = commandLine.substr(begin, end);

			commandLine = commandLine.erase(0, end + 2);
			end = commandLine.find(", ");
			if (end == -1)
				end = commandLine.size();
			i++;
		}
		i--;


		if (command == "exit")
		{
			cout << "EXIT!";
			return;
		}
		else if (command == "addDwelling")
		{
			string type = parameters[0];
			double price = stod(parameters[1]);
			bool isProfitable{};
			if (parameters[2] == "true")
				isProfitable = true;
			else
				isProfitable = false;

			Dwelling dwelling = this->agency.addDwelling(type, price, isProfitable);
		}
		else if (command == "addClient")
		{
			if (parameters[2] != "")
			{
				shared_ptr<Client> client = make_shared<WealthyClient>(parameters[0], stod(parameters[1]), stod(parameters[2]));
				this->agency.addClient(client);
			}
			else
			{
				shared_ptr<Client> client = make_shared<NormalClient>(parameters[0], stod(parameters[1]));
				this->agency.addClient(client);
			}
		}
		else if (command == "list")
		{
			if (parameters[0] == "")
			{
				ui_printAll();
			}
			else
			{
				ui_printInterested(parameters[1]);
			}
		}
		else if (command == "fileLocation")
			this->ui_saveClients(parameters[0]);
	}
}

void Ui::ui_addDwelling()
{
	string type{};
	double price{};
	bool isProfitable{};

	Dwelling dwelling = this->agency.addDwelling(type, price, isProfitable);
}


void Ui::ui_saveClients(string filename)
{
	this->agency.writeToFile(filename);
}

void Ui::ui_printAll()
{
	vector<shared_ptr<Client>> clients = this->agency.getClients();
	vector<Dwelling> dwellings = this->agency.getDwellings();

	for (auto client : clients)
	{
		cout << client->toString() << "\n";
	}

	for (auto dwelling : dwellings)
	{
		cout << dwelling.toString() << "\n";
	}
}

void Ui::ui_printInterested(string dwellingType)
{
	vector<shared_ptr<Client>> clients = this->agency.getInterestedClients(dwellingType);

	for (auto client : clients)
	{
		cout << client->toString() << "\n";
	}
}
