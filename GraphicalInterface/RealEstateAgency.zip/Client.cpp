#include "Client.h"
#include <sstream>

Client::Client(string _name, double _salary) : name{ _name }, salary{ _salary }
{
}

Client::~Client()
{
}

double Client::totalIncome() const
{
	return this->salary;
}

string Client::toString() const
{
	stringstream stream;
	stream << this->name << "," << this->salary;
	return stream.str();
}

string Client::getName() const
{
	return this->name;
}

bool Client::operator==(const Client& _client) const
{
	return this->name == _client.name;
}


NormalClient::NormalClient(string _name, double _salary) : Client{_name, _salary}
{
}

NormalClient::~NormalClient()
{
}

bool NormalClient::isInterested(const Dwelling& _dwelling) const
{
	if(_dwelling.normalBankRate() <= this->salary)
		return true;
	else
		return 0;
}

WealthyClient::WealthyClient(string _name, double _salary, double _investments): Client{_name, _salary}, moneyFromInvestments{_investments}
{
}

WealthyClient::~WealthyClient()
{
}

double WealthyClient::totalIncome() const
{
	return this->moneyFromInvestments + this->salary;
}

string WealthyClient::toString() const
{
	stringstream stream;
	stream <<  this->name << "," << this->salary << "," << this->moneyFromInvestments;
	return stream.str();
}

bool WealthyClient::isInterested(const Dwelling& _dwelling) const
{
	double totalIncome = this->salary + this->moneyFromInvestments;

	if (_dwelling.largeBankRate() <= totalIncome && _dwelling.profitableDwelling())
		return true;
	else
		return false;
}

ostream& operator<<(ostream& stream, const Client& _client)
{
	stream << _client.toString() << "\n";
	return stream;
}
