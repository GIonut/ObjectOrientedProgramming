#pragma once
#include "Repository.h"

class RealEstateAgency
{
private:
	ClientsRepository& clients;
	DwellingsRepository& dwellings;

public:
	RealEstateAgency(ClientsRepository& _clients, DwellingsRepository& _dwellings );
	~RealEstateAgency();

	Dwelling addDwelling(string _type, double _price, bool _isProfitable);
	void removeClient(const string& _name);
	vector<shared_ptr<Client>> getInterestedClients(string dwellingType) const;
	void writeToFile(const string& filename) const;
	vector<shared_ptr<Client>> getClients() const;
	vector<Dwelling> getDwellings() const;
	void addClient(shared_ptr<Client> client);

};

