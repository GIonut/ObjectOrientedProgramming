#include "RealEstateAgency.h"

RealEstateAgency::RealEstateAgency(ClientsRepository& _clients, DwellingsRepository& _dwellings) : clients{ _clients }, dwellings{ _dwellings }
{
}

RealEstateAgency::~RealEstateAgency()
{
}

Dwelling RealEstateAgency::addDwelling(string _type, double _price, bool _isProfitable)
{
	Dwelling dwelling{ _type, _price, _isProfitable };
	this->dwellings.add(dwelling);
	return dwelling;
}

void RealEstateAgency::removeClient(const string& _name)
{
	this->clients.remove(_name);
}

vector<shared_ptr<Client>> RealEstateAgency::getInterestedClients(string dwellingType) const
{
	vector<shared_ptr<Client>> interestedClients{};
	vector<shared_ptr<Client>> clients = this->clients.get();
	vector<Dwelling> dwellings = this->dwellings.get();

	Dwelling dwelling(dwellingType, 0, false);
	
	for (auto d : dwellings)
	{
		if (d.getType() == dwellingType)
			dwelling = d;
	}

	for (auto client : clients)
	{
		if (client->isInterested(dwelling))
			interestedClients.push_back(client);
	}

	return interestedClients;
}

void RealEstateAgency::writeToFile(const string& filename) const
{
	this->clients.write(filename);
}

vector<shared_ptr<Client>> RealEstateAgency::getClients() const
{
	return this->clients.get();
}

vector<Dwelling> RealEstateAgency::getDwellings() const
{
	return this->dwellings.get();
}

void RealEstateAgency::addClient(shared_ptr<Client> client)
{
	this->clients.add(client);
}
