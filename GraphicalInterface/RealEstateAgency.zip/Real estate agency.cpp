#include <iostream>
#include "Client.h"
#include "Repository.h"
#include "RealEstateAgency.h"
#include "Ui.h"

void addClients(ClientsRepository& clients)
{
    shared_ptr<Client> client= make_shared<NormalClient>("John Snow", 70000);
    clients.clients.push_back(client);

    client = make_shared<NormalClient>("Ion Pop", 85000);
    clients.clients.push_back(client);

    client = make_shared<WealthyClient>("Etta James", 275000, 350000);
    clients.clients.push_back(client);

    client = make_shared<WealthyClient>("Lady Gaga", 425000, 550000);
    clients.clients.push_back(client);
}

int main()
{
    {
        ClientsRepository clients{};
        DwellingsRepository dwellings{};

        //addClients(clients);

        RealEstateAgency agency{ clients, dwellings };
        Ui ui{ agency };
        ui.ui_run(); 
    }


}

