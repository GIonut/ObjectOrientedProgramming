#pragma once
#include <string>
#include "Dwelling.h"
#include <iostream>

using namespace std;

class Client
{
protected:
	string name{};
	double salary{};

	Client(string _name, double _salary);

public:
	virtual ~Client();
	virtual double totalIncome() const;
	virtual string toString() const;
	virtual bool isInterested(const Dwelling& _dwelling) const = 0;
	virtual string getName() const;

	bool operator==(const Client&) const;
	friend ostream& operator<<(ostream& stream, const Client& _client);

};

class NormalClient
	: public Client
{
public:
	NormalClient(string _name, double _salary);
	~NormalClient();

	bool isInterested(const Dwelling& _dwelling) const override;
};

class WealthyClient
	: public Client
{
private:
	double moneyFromInvestments{};

public:
	WealthyClient(string _name, double _salary, double _investments);
	~WealthyClient();

	double totalIncome() const;
	string toString() const;
	bool isInterested(const Dwelling& _dwelling) const override;
};