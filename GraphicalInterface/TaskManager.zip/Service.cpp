#include "Service.h"
#include "MyException.h"

Service::Service(TaskRepository& _repository) : repository(_repository)
{
}

void Service::add(string _description, string _status, int _userId)
{
	Task task(_description, _status, _userId);
	this->repository.add(task);
	this->notify();
}

vector<Task> Service::sort()
{
	vector<Task> elements = this->repository.tasks;
	std::sort(elements.begin(), elements.end(), [](auto i, auto j) { return i.status < j.status; });
	return elements;
}

void Service::remove(string _description)
{
	this->repository.remove(_description);
	this->notify();
}

void Service::updateStatus(Task task, Programmer programmer)
{
	if (task.status != "open")
		throw MyException();

	for (Task& element : this->repository.tasks)
	{
		if (element.description == task.description)
		{
			element.status = "in progress";
			element.userId = programmer.id;
			this->notify();
			return;
		}
	}
}

string Service::getUser(Task task)
{
	for (auto programmer : this->repository.programmers)
	{
		if (programmer.id == task.userId)
			return programmer.name;
	}
}

void Service::close(Task task)
{
	for (Task& element : this->repository.tasks)
	{
		if (element.description == task.description)
		{
			element.status = "closed";
			this->notify();
			return;
		}
	}
}