#include "TaskRepository.h"

TaskRepository::TaskRepository(string file1, string file2): file1(file1), file2(file2)
{
	ifstream fin(file1);
	Programmer programmer;
	while (fin >> programmer)
		this->programmers.push_back(programmer);
	fin.close();
	ifstream fin1(file2);
	Task task;
	while (fin1 >> task)
		this->tasks.push_back(task);
	fin1.close();

}

TaskRepository::~TaskRepository()
{
	ofstream fout(this->file2);
	for (auto task : tasks)
		fout << task << "\n";
	fout.close();
}

void TaskRepository::add(Task& task)
{
	this->tasks.push_back(task);
}

void TaskRepository::remove(string _description)
{
	for (auto it = this->tasks.begin(); it != this->tasks.end(); it++)
	{
		if (it->description == _description)
		{
			this->tasks.erase(it);
			return;
		}
	}
}