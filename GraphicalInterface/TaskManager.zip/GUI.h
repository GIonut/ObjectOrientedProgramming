#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_GUI.h"
#include "Service.h"
#include "Domain.h"
#include "Observer.h"
#include <string>

using namespace std;

class GUI : public QMainWindow, public Observer
{
    Q_OBJECT

public:
    GUI(Service& service, Programmer programmer, QWidget *parent = Q_NULLPTR);

private:
    Ui::GUIClass ui;
    Service& service;
    Programmer programmer;

    void update() override;
    void populateList();
    int getSelectedIndex();
public slots:
    void add();
    void remove();
    void start();
    void done();
    void selected();
};
