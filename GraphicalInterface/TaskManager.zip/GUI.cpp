#include "GUI.h"
#include "MyException.h"
#include <qmessagebox.h>

GUI::GUI(Service& service, Programmer programmer, QWidget *parent)
    : QMainWindow(parent), service(service), programmer(programmer)
{
    ui.setupUi(this);
    this->setWindowTitle(QString::fromStdString(programmer.name));
    this->populateList();
}

void GUI::update()
{
    this->populateList();
}

void GUI::populateList()
{
    this->ui.listWidget->clear();
    auto elements = this->service.sort();

    for (auto task : elements)
    {
        if (task.status == "in progress")
        {
            string user = this->service.getUser(task);
            this->ui.listWidget->addItem(QString::fromStdString(task.description + " " + task.status + " " + user));
        }
        else
            this->ui.listWidget->addItem(QString::fromStdString(task.description + " " + task.status));
    }
}


int GUI::getSelectedIndex()
{
    QModelIndexList selectedIndexes = this->ui.listWidget->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}

void GUI::add()
{
    string description = this->ui.lineEdit->text().toStdString();
    string status = "open";
    int userId = this->programmer.id;

    this->service.add(description, status, userId);
}

void GUI::remove()
{
    QListWidgetItem* item = this->ui.listWidget->currentItem();
    string text = item->text().toStdString();
    string description = text.substr(0, text.find(" "));

    this->service.remove(description);
}

void GUI::start()
{
    int index = this->getSelectedIndex();

    auto elements = this->service.sort();
    try {
        this->service.updateStatus(elements[index], this->programmer);
    }
    catch (MyException& e)
    {
        QMessageBox::critical(this, "Error", QString::fromStdString(string(e.what())));
    }
}

void GUI::done()
{
    int index = this->getSelectedIndex();
    auto elements = this->service.sort();
    this->service.close(elements[index]);
}

void GUI::selected()
{
    int index = this->getSelectedIndex();
    auto elements = this->service.sort();
    if (this->programmer.id == elements[index].userId && elements[index].status == "in progress")
        this->ui.pushButton_4->setDisabled(false);
    else 
        this->ui.pushButton_4->setDisabled(true);
}