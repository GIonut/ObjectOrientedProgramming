#pragma once
#include "Domain.h"
#include <string>
#include <vector>
#include <fstream>

using namespace std; 

class TaskRepository
{
	string file1, file2;
public:
	TaskRepository(string file1, string file2);
	~TaskRepository();
	vector<Programmer> programmers;
	vector<Task> tasks;
	void add(Task& task);
	void remove(string _description);

};

