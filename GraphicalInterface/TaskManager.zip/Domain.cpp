#include "Domain.h"
#include <sstream>

istream& operator>>(istream& reader, Programmer& programmer)
{
	string line;
	getline(reader, line);
	if (line.empty())
		return reader;
	stringstream ss(line);
	string description;
	getline(ss, description, ';');
	programmer.name = description;
	string status;
	getline(ss, status, ';');
	programmer.id = stoi(status);
	return reader;
}

ostream& operator<<(ostream& writer, Task& task)
{
	writer << task.description << ";" << task.status << ";" << task.userId;
	return writer;
}

istream& operator>>(istream& reader, Task& task)
{
	string line;
	getline(reader, line);
	if (line.empty())
		return reader;
	stringstream ss(line);
	string description;
	getline(ss, description, ';');
	task.description = description;
	string status;
	getline(ss, status, ';');
	task.status = status;
	string userId;
	getline(ss, userId, ';');
	if (userId.empty())
		task.userId = 0;
	else 
		task.userId = stoi(userId);
	return reader;
}

Task::Task(string _description, string _status, int _userId) : description(_description), status(_status), userId(_userId)
{
}

string Task::toString()
{
	return this->description + " " + this->status + " " + " " + to_string(this->userId);
}
