#pragma once
#include<string>
#include<iostream>
using namespace std;

class Programmer
{
public:
	string name;
	int id;
	friend istream& operator>>(istream& reader, Programmer& programmer);
};

class Task
{
public:
	string description;
	string status;
	int userId;
	Task() {}
	Task(string _description, string _status, int _userId);
	friend ostream& operator<<(ostream& writer, Task& task);
	friend istream& operator>>(istream& reader, Task& task);
	string toString();
};
