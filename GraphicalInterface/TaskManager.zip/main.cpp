#include "GUI.h"
#include <QtWidgets/QApplication>
#include "Service.h"
#include "TaskRepository.h"
#include "Domain.h"
#include "Observer.h"

int main(int argc, char* argv[])
{
    QApplication a(argc, argv);
    TaskRepository repository("programmers.txt", "tasks.txt");
    Service service{ repository };
    for (auto programmer : service.repository.programmers)
    {
        GUI* w = new GUI{ service, programmer };
        service.addObserver(w);
        w->show();
    }
    return a.exec();
}
