#include "Observer.h"

void Subject::addObserver(Observer* _observer)
{
	this->observers.push_back(_observer);
}

void Subject::removeObserver(Observer* _observer)
{
	auto iterator = std::find(this->observers.begin(), this->observers.end(), _observer);
	if (iterator != this->observers.end())
		this->observers.erase(iterator);

}

void Subject::notify()
{
	for (auto observer : this->observers)
		observer->update();
}

