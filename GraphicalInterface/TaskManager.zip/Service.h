#pragma once
#include"TaskRepository.h"
#include <algorithm>
#include "Observer.h"

class Service : public Subject
{
public:
	Service(TaskRepository& _repository);
	TaskRepository& repository;
	void add(string _description, string _status, int _userId);
	void remove(string _description);
	vector<Task> sort();
	void updateStatus(Task task, Programmer programmer);
	string getUser(Task task);
	void close(Task task);
};

