#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Quiz.h"
#include "Service.h"

class Quiz : public QMainWindow, public Observer
{
    Q_OBJECT

public:
    Quiz(Service& _service, Class1 _class1, QWidget *parent = Q_NULLPTR);

private:
    Ui::QuizClass ui;
    Service& service;
    Class1 class1;
    void update() override;

    int getSelectedIndex();
    void populateList();
    int score = 0;

public slots:
    void answer();
    void selection(const QModelIndex& index);
};
