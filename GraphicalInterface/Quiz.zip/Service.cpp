#include "Service.h"

Service::Service(Repository& _repository): repository(_repository)
{
}

void Service::add(int _attribute1, string _attribute2, string _attribute3, int _attribute4)
{
	if (_attribute2.empty())
		throw exception("Invalid object!");
	for (auto class2 : this->repository.classes2)
	{
		if(class2.attribute1 == _attribute1)
			throw exception("Invalid object!");
	}

	Class2 class2(_attribute1, _attribute2, _attribute3, _attribute4);
	this->repository.add(class2);
	this->notify();
}

vector<Class2> Service::filterByScore()
{
	vector<Class2> elements = this->repository.classes2;
	sort(elements.begin(), elements.end(), [](auto i, auto j) { return i.attribute4 > j.attribute4; });
	return elements;
}

vector<Class2> Service::filterById()
{
	vector<Class2> elements = this->repository.classes2;
	sort(elements.begin(), elements.end(), [](auto i, auto j) { return i.attribute1 < j.attribute1; });
	return elements;
}

bool Service::checkAnswer(int id, string answer)
{
	for (auto class2 : this->repository.classes2)
		if (class2.attribute1 == id && class2.attribute3 == answer)
			return true;
	return false;
}
