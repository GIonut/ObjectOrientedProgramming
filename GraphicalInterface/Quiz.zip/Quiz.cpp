#include "Quiz.h"
#include<sstream>

Quiz::Quiz(Service& _service, Class1 _class1, QWidget *parent)
    : QMainWindow(parent), service(_service), class1(_class1)
{
    ui.setupUi(this);
    this->setWindowTitle(QString::fromStdString(_class1.attribute1));
    this->populateList();
}

void Quiz::update()
{
    this->populateList();
}

void Quiz::populateList()
{
    this->score = 0;
    this->ui.score->setText(QString::number(0));
    this->ui.listWidget->clear();
    for (Class2& class2 : this->service.filterByScore())
        this->ui.listWidget->addItem(QString::fromStdString(to_string(class2.attribute1) + " " + class2.attribute2 + " " + to_string(class2.attribute4)));
}

void Quiz::selection(const QModelIndex& index)
{
    this->ui.lineEdit->clear();
    QListWidgetItem* item = this->ui.listWidget->currentItem();
    if (item->background().color() == Qt::red || item->background().color() == Qt::green)
    {
        this->ui.pushButton->setDisabled(true);
        return;
    }
    this->ui.pushButton->setDisabled(false);
}

int Quiz::getSelectedIndex()
{
    QModelIndexList selectedIndexes = this->ui.listWidget->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}

void Quiz::answer()
{
    QListWidgetItem* item = this->ui.listWidget->currentItem();
    string question = item->text().toStdString();
    int questionId = stoi(question.substr(0, question.find(" ")));
    int questionScore = stoi(question.substr(question.rfind(" ")));

    string participantAnswer = this->ui.lineEdit->text().toStdString();
    if (this->service.checkAnswer(questionId, participantAnswer))
    {
        QBrush* greenBrush = new QBrush{ Qt::green, Qt::SolidPattern };
        item->setBackground(*greenBrush);
        this->score += questionScore;
        this->ui.score->setText(QString::number(this->score));
    }
    else
    {
        QBrush* redBrush = new QBrush{ Qt::red, Qt::SolidPattern };
        item->setBackground(*redBrush);
    }
}
