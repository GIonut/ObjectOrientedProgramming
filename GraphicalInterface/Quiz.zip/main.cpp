#include "Quiz.h"
#include <QtWidgets/QApplication>
#include "Service.h"
#include "Repository.h"
#include "Domain.h"
#include "Presenter.h"
#include"Observer.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Repository repository("participants.txt", "questions.txt");
    Service service{repository};
    for (auto class1 : service.repository.classes1)
    {
        Quiz* w = new Quiz{ service, class1 };
        service.addObserver(w);
        w->show();
    }
    Presenter presenter{ service };
    service.addObserver(&presenter);
    presenter.show();
    return a.exec();
}
