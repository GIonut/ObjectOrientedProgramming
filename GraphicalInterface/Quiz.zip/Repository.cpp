#include "Repository.h"
#include <fstream>


Repository::Repository(string file1, string file2): file1(file1), file2(file2)
{
	ifstream fin(file1);
	Class1 class1;
	while (fin >> class1)
		this->classes1.push_back(class1);
	fin.close();
	ifstream fin1(file2);
	Class2 class2;
	while (fin1 >> class2)
		this->classes2.push_back(class2);
	fin1.close();
	
}

Repository::~Repository()
{
	ofstream fout(this->file2);
	for (auto class2 : classes2)
		fout << class2 << "\n";
	fout.close();
}

void Repository::add(Class2& class2)
{
	this->classes2.push_back(class2);
}
