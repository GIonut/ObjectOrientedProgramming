#include "Presenter.h"
#include<qmessagebox.h>
Presenter::Presenter(Service& _service, QWidget *parent)
	: QWidget(parent), service(_service)
{
	ui.setupUi(this);
	this->setWindowTitle("Presenter");
	this->populateList();
}

Presenter::~Presenter()
{
}

void Presenter::populateList()
{
	this->ui.listWidget->clear();
	for (Class2& class2 : this->service.filterById())
		this->ui.listWidget->addItem(QString::fromStdString(to_string(class2.attribute1) + " " + class2.attribute2 + " " + class2.attribute3 + " " + to_string(class2.attribute4)));

}

void Presenter::update()
{
	this->populateList();
}

void Presenter::add()
{
	string attribute1 = this->ui.lineEdit->text().toStdString();
	string attribute2 = this->ui.lineEdit_2->text().toStdString();
	string attribute3 = this->ui.lineEdit_3->text().toStdString();
	string attribute4 = this->ui.lineEdit_4->text().toStdString();

	try {
		this->service.add(stoi(attribute1), attribute2, attribute3, stoi(attribute4));
	}
	catch (exception& e)
	{
		QMessageBox::critical(this, "Error", e.what());
		return;
	}

	this->update();
}

