#pragma once
#include "Domain.h"
#include <vector>

using namespace std;

class Repository
{
	string file1, file2;
public:
	vector<Class1> classes1;
	vector<Class2> classes2;
	Repository(string file1, string file2);
	~Repository();
	void add(Class2& class2);
};

