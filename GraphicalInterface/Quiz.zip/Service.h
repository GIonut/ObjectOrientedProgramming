#pragma once
#include"Repository.h"
#include <algorithm>
#include "Observer.h"

class Service : public Subject
{
public:
	Service(Repository& _repository);
	Repository& repository;
	void add(int _attribute1, string _attribute2, string _attribute3, int _attribute4);
	vector<Class2> filterByScore();
	vector<Class2> filterById();
	bool checkAnswer(int id, string answer);
};

