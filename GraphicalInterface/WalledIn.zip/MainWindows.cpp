#include "MainWindows.h"

MainWindows::MainWindows(Enchantment& _enchantment, QWidget *parent)
	: QWidget(parent), enchantment{ _enchantment }
{
	uiMainWindows.setupUi(this);
	uiMainWindows.stackedWidget->insertWidget(1, &this->_modeA);
	uiMainWindows.stackedWidget->insertWidget(2, &this->_modeB);

	connect(&this->_modeA, SIGNAL(goHomeClick()), this, SLOT(toMainPage()));
	connect(&this->_modeB, SIGNAL(goHomeClick()), this, SLOT(toMainPage()));
}

MainWindows::~MainWindows()
{
}

void MainWindows::switchToModeB()
{
	uiMainWindows.stackedWidget->setCurrentIndex(2);
}

void MainWindows::switchToModeA()
{
	uiMainWindows.stackedWidget->setCurrentIndex(1);
}

void MainWindows::toMainPage()
{
	uiMainWindows.stackedWidget->setCurrentWidget(uiMainWindows.home);
}