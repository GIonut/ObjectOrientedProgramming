#include "ModeB.h"

#include <qmessagebox.h>
#include <regex>

ModeB::ModeB(Enchantment& _enchantment, QWidget *parent)
	: QWidget(parent), enchantment{_enchantment}
{
	uiModeB.setupUi(this);
	next();
}

ModeB::~ModeB()
{
}

void ModeB::next()
{
	NorvenTurret turret{};

	try {
		turret = this->enchantment.next();
	}
	catch (RepoError& exception)
	{
		return;
	}
	this->uiModeB.wall_locationLineEdit->setText(QString::fromStdString(turret.getLocation()));
	this->uiModeB.wall_sizeLineEdit->setText(QString::fromStdString(turret.getSize()));
	this->uiModeB.wall_auraLevelLineEdit->setText(QString::fromStdString(to_string(turret.getAuraLevel())));
	this->uiModeB.wall_separatePartsLineEdit->setText(QString::fromStdString(to_string(turret.getSeparateParts())));
	this->uiModeB.wall_visionLineEdit->setText(QString::fromStdString(turret.getVision()));

}

void ModeB::save()
{
	NorvenTurret turret = this->enchantment.getCurrentTurret();

	try {
		this->enchantment.saveTurretOnWalls(turret.getLocation());
	}
	catch (RepoError& error)
	{
		QMessageBox::critical(this, "Error", "The turret is already saved!");
		return;
	}

	this->populateList();

	int lastTurret = this->enchantment.getAllTurretsOnWalls().size() - 1;
	this->uiModeB.wall_turretsListWidget->setCurrentRow(lastTurret);
}

void ModeB::populateList()
{
	this->uiModeB.wall_turretsListWidget->clear();

	vector<NorvenTurret> turrets = this->enchantment.getAllTurretsOnWalls();

	for (NorvenTurret& turret : turrets)
		this->uiModeB.wall_turretsListWidget->addItem(QString::fromStdString(turret.getLocation()) + "-" + QString::fromStdString(turret.getVision()));
		
}

void ModeB::openExternally()
{
	string path = this->enchantment.getPath();
	regex pattern(".csv");
	smatch match;

	if (regex_search(path, match, pattern))
	{
		string command = "\start excel \"" + path;
		const char* mycommand = command.c_str();
		system(mycommand);
	}
	else
	{
		string command = "\start chrome \"" + path;
		const char* mycommand = command.c_str();
		system(mycommand);
	}
}

void ModeB::deleteFromList()
{
	int selectedIndex = this->getSelectedIndex();
	if (selectedIndex < 0)
	{
		return;
	}

	NorvenTurret turret = this->enchantment.getAllTurretsOnWalls()[selectedIndex];
	this->enchantment.deleteTurretFromWalls(turret.getLocation());

	this->populateList();
}

int ModeB::getSelectedIndex() const
{
	QModelIndexList selectedIndexes = this->uiModeB.wall_turretsListWidget->selectionModel()->selectedIndexes();

	if (selectedIndexes.size() == 0)
	{
		this->uiModeB.wall_locationLineEdit->clear();
		this->uiModeB.wall_sizeLineEdit->clear();
		this->uiModeB.wall_auraLevelLineEdit->clear();
		this->uiModeB.wall_separatePartsLineEdit->clear();
		this->uiModeB.wall_visionLineEdit->clear();
		return -1;
	}

	int selectedIndex = selectedIndexes.at(0).row();
	return selectedIndex;
}

void ModeB::toMainPage()
{
	emit this->goHomeClick();
}