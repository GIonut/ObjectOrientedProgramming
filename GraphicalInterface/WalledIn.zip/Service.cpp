#include "Service.h"


Turrets Enchantment::getAllTurretsInEncyclopedia() const
{
	return this->encyclopedia->getTurrets();
}

void Enchantment::addTurretToEncyclopedia(const string& location, const string& size, int auraLevel, int separateParts, const string& vision)
{
	NorvenTurret turret{ location, size, auraLevel, separateParts, vision };

	this->encyclopedia->addTurret(turret);
}

void Enchantment::deleteTurretFromEncyclopedia(const string& location)
{
	NorvenTurret turret{ location, "", 0, 0, "" };
	this->encyclopedia->deleteTurret(turret);
}

void Enchantment::updateTurretFromEncyclopedia(const string& location, const string& size, int auraLevel, int separateParts, const string& vision)
{
	NorvenTurret newTurret{ location, size, auraLevel, separateParts, vision };
	this->encyclopedia->updateTurret(newTurret);
}

Turrets Enchantment::getAllTurretsOnWalls() const
{
	return this->walls->getTurretsOnWalls();
}

NorvenTurret Enchantment::next()
{
	return this->encyclopedia->nextTurret();
}

void Enchantment::saveTurretOnWalls(const string& location)
{
	this->walls->addTurret(this->encyclopedia->findTurretByLocation(location));
}

NorvenTurret Enchantment::getCurrentTurret() const
{
	return this->getAllTurretsInEncyclopedia()[this->encyclopedia->getCurrent()-1];
}

void Enchantment::deleteTurretFromWalls(const string& location)
{
	NorvenTurret turret{ location, "", 0, 0, "" };
	this->walls->deleteTurret(turret);
}

string& Enchantment::getPath()
{
	return this->walls->getFileLocation();
}