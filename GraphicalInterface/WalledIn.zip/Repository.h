#pragma once
#include <vector>
#include "Domain.h"
#include <iostream>
#include <fstream>


typedef vector<NorvenTurret> Turrets;

class Encyclopedia
{
private:
	int currentTurret = 0;

public:
	Encyclopedia();
	virtual ~Encyclopedia() {};

	virtual Turrets getTurrets() = 0;

	virtual void addTurret(const NorvenTurret& turret) = 0;

	virtual void deleteTurret(const NorvenTurret& turret) = 0;

	virtual void updateTurret(const NorvenTurret& newTurret) = 0;


	virtual NorvenTurret findTurretByLocation(const string& location) = 0;

	virtual NorvenTurret nextTurret() = 0;


	virtual int getCurrent() const = 0;
};

class FileRepo : public Encyclopedia
{
private:
	string filename{};
	int currentTurret = 0;

public:
	FileRepo(const string _filename);
	~FileRepo() {};

	virtual Turrets getTurrets() override;

	virtual void addTurret(const NorvenTurret& turret) override;

	virtual void deleteTurret(const NorvenTurret& turret) override;

	virtual void updateTurret(const NorvenTurret& newTurret) override;

	virtual NorvenTurret findTurretByLocation(const string& location) override;

	virtual NorvenTurret nextTurret() override;
	int getCurrent() const override;
};

class InMeomoryRepo : public Encyclopedia
{
private:
	vector<NorvenTurret> turrets;
	int currentTurret = 0;

public:
	InMeomoryRepo();
	~InMeomoryRepo() {};

	virtual Turrets getTurrets() override;

	virtual void addTurret(const NorvenTurret& turret) override;

	virtual void deleteTurret(const NorvenTurret& turret) override;

	virtual void updateTurret(const NorvenTurret& newTurret) override;

	virtual NorvenTurret findTurretByLocation(const string& location) override;

	virtual NorvenTurret nextTurret() override;

	int getCurrent() const override;
};