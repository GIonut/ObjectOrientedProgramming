#include "WalledIn.h"
#include "Exceptions.h"
#include <qmessagebox.h>

#include <QApplication>
#include <QtWidgets/QMainWindow>
#include  <QtCharts/QChartView>
#include  <QtCharts/QBarSeries>
#include  <QtCharts/QBarSet>
#include  <QtCharts/QLegend>
#include  <QtCharts/QBarCategoryAxis>
#include  <QtCharts/QHorizontalStackedBarSeries>
#include  <QtCharts/QLineSeries>
#include  <QtCharts/QCategoryAxis>

#include <algorithm>

QT_CHARTS_USE_NAMESPACE

WalledIn::WalledIn(Enchantment& _enchantment, QWidget *parent): QMainWindow(parent), enchantment{_enchantment}
{
	ui.setupUi(this);
	this->populateList();
	this->connectSignalsAndSlots();
	
}

void WalledIn::populateList()
{
	this->ui.turretsListWidget->clear();

	vector<NorvenTurret> turrets = this->enchantment.getAllTurretsInEncyclopedia();

	for (NorvenTurret& turret : turrets)
		this->ui.turretsListWidget->addItem(QString::fromStdString(turret.getLocation()) + "-" + QString::fromStdString(turret.getVision()));

}

void WalledIn::connectSignalsAndSlots()
{
	QObject::connect(this->ui.turretsListWidget, &QListWidget::itemSelectionChanged, [this] {

		int selectedIndex = this->getSelectedIndex();

		if (selectedIndex < 0)
			return;

		NorvenTurret turret = this->enchantment.getAllTurretsInEncyclopedia()[selectedIndex];

		this->ui.locationLineEdit->setText(QString::fromStdString(turret.getLocation()));
		this->ui.sizeLineEdit->setText(QString::fromStdString(turret.getSize()));
		this->ui.auraLevelLineEdit->setText(QString::fromStdString(to_string(turret.getAuraLevel())));
		this->ui.separatePartsLineEdit->setText(QString::fromStdString(to_string(turret.getSeparateParts())));
		this->ui.visionLineEdit->setText(QString::fromStdString(turret.getVision()));

		});

}

int WalledIn::getSelectedIndex() const
{
	QModelIndexList selectedIndexes = this->ui.turretsListWidget->selectionModel()->selectedIndexes();

	if (selectedIndexes.size() == 0)
	{
		this->ui.locationLineEdit->clear();
		this->ui.sizeLineEdit->clear();
		this->ui.auraLevelLineEdit->clear();
		this->ui.separatePartsLineEdit->clear();
		this->ui.visionLineEdit->clear();
		return -1;
	}

	int selectedIndex = selectedIndexes.at(0).row();
	return selectedIndex;
}

void WalledIn::addTurret()
{
	string location = this->ui.locationLineEdit->text().toStdString();
	string size = this->ui.sizeLineEdit->text().toStdString();
	string auraLevel = this->ui.auraLevelLineEdit->text().toStdString();
	string separateParts = this->ui.separatePartsLineEdit->text().toStdString();
	string vision = this->ui.visionLineEdit->text().toStdString();

	try {
		this->enchantment.addTurretToEncyclopedia(location, size, stoi(auraLevel), stoi(separateParts), vision);
	}
	catch (RepoError& error)
	{
		QMessageBox::critical(this, "Error", "There is another turret with the same location!");
		return;
	}
	catch (...)
	{
		QMessageBox::critical(this, "Error", "Provide the correct data!");
		return;
	}

	this->populateList();

	int lastTurret = this->enchantment.getAllTurretsInEncyclopedia().size() - 1;
	this->ui.turretsListWidget->setCurrentRow(lastTurret);
}

void WalledIn::deleteTurret()
{
	int selectedIndex = this->getSelectedIndex();
	if (selectedIndex < 0)
	{
		QMessageBox::critical(this, "Error", "Please, select a turret first!");
		return;
	}

	NorvenTurret turret = this->enchantment.getAllTurretsInEncyclopedia()[selectedIndex];
	this->enchantment.deleteTurretFromEncyclopedia(turret.getLocation());

	this->populateList();

	//emit deleteFromWalls();
}

void WalledIn::showChart()
{
	QBarSeries* series = new QBarSeries();

	vector<NorvenTurret> turrets = this->enchantment.getAllTurretsInEncyclopedia();
	for (const NorvenTurret& turret : turrets)
	{
		QBarSet* set = new QBarSet(QString::fromStdString(turret.getLocation()));
		*set << turret.getSeparateParts();
		series->append(set);
	}

	QChart* chart = new QChart();
	chart->addSeries(series);

	QStringList categories;
	categories << "Separate Parts";

	QBarCategoryAxis* axis = new QBarCategoryAxis();
	axis->append(categories);
	chart->createDefaultAxes();
	chart->setAxisX(axis, series);
	chart->legend()->setVisible(true);
	chart->legend()->setAlignment(Qt::AlignBottom);

	QChartView* chartView = new QChartView(chart);
	chartView->setRenderHint(QPainter::Antialiasing);
	QPalette palette = qApp->palette();
	palette.setColor(QPalette::Window, QRgb(0xffffff));
	palette.setColor(QPalette::WindowText, QRgb(0x404040));
	qApp->setPalette(palette);

	chartView->show();
}

void WalledIn::updateTurret()
{
	string location = this->ui.locationLineEdit->text().toStdString();
	string size = this->ui.sizeLineEdit->text().toStdString();
	string auraLevel = this->ui.auraLevelLineEdit->text().toStdString();
	string separateParts = this->ui.separatePartsLineEdit->text().toStdString();
	string vision = this->ui.visionLineEdit->text().toStdString();

	try {
		this->enchantment.updateTurretFromEncyclopedia(location, size, stoi(auraLevel), stoi(separateParts), vision);
	}
	catch (RepoError& error)
	{
		QMessageBox::critical(this, "Error", "There is no turret at the given location!");
		return;
	}
	catch (...)
	{
		QMessageBox::critical(this, "Error", "Provide the correct data!");
		return;
	}

	this->populateList();

	vector<NorvenTurret> turrets = this->enchantment.getAllTurretsInEncyclopedia();
	
	int currentTurret = 0;
	NorvenTurret turret{ location, size, stoi(auraLevel), stoi(separateParts), vision };
	
	std::find_if(turrets.begin(), turrets.end(), [&](const NorvenTurret& turret) {
		currentTurret++;
		return turret.getLocation() == location;
		});

	this->ui.turretsListWidget->setCurrentRow(currentTurret-1);
	
}

void WalledIn::toMainPage()
{
	emit this->goHomeClick();
}

void WalledIn::filter()
{
	this->ui.turretsListWidget->clear();

	Turrets turrets = this->enchantment.getAllTurretsInEncyclopedia();
	int count = 0;
	Turrets::iterator i = turrets.begin();
	sort(turrets.begin(), turrets.end(), [&](auto i, auto j) { return i.getLocation() < j.getLocation(); });

	for (NorvenTurret& turret : turrets)
		this->ui.turretsListWidget->addItem(QString::fromStdString(turret.getLocation()) + "-" + QString::fromStdString(turret.getVision()));

}
