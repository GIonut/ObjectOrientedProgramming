#include "Walls.h"
#include <algorithm>
#include <iterator>
#include <sstream>
#include "Exceptions.h"

void loadDataFromCSV(Turrets& turrets, const string& path)
{
	ifstream inputFile{ path };
	string line{};
	
	for(line; getline(inputFile, line);)
	{
		string temporaryline{};
		for (unsigned int i = 0; i < line.size(); i++)
		{
			if (line[i] == ',')
				temporaryline += ", ";
			else
				temporaryline += line[i];
		}

		istringstream inputLine(temporaryline);
		NorvenTurret turret{};
		inputLine >> turret;
		turrets.push_back(turret);
	}
}

void saveDataToCSV(Turrets& turrets, const string& path)
{
	string line{};
	ofstream outputFile(path);
	ostringstream outputLine;
	for (auto turret : turrets)
	{
		outputLine << turret;
		line = outputLine.str();
		string temporaryline{};
		for (unsigned int i = 0; i < line.size(); i++)
		{
			if (line[i] == ',')
			{
				temporaryline += ",";
				i++;
			}
			else
				temporaryline += line[i];
		}
		outputFile << temporaryline;
		outputLine.str("");
		outputLine.clear();
	}
}

CSVWalls::CSVWalls(const string myListLocation)
{
	this->fileLocation = myListLocation;
}

void CSVWalls::addTurret(const NorvenTurret& turret)
{
	Turrets turrets{};
	loadDataFromCSV(turrets, this->fileLocation);
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	//if the turret we want to add does already exist in the repo, throw an error
	if (find(first, last, turret) != last)
		throw RepoError();

	turrets.insert(last, turret);

	saveDataToCSV(turrets, this->fileLocation);
}


Turrets CSVWalls::getTurretsOnWalls() const
{
	Turrets turrets{};
	loadDataFromCSV(turrets, this->fileLocation);
	return turrets;
}


string& CSVWalls::getFileLocation()
{
	return this->fileLocation;
}

void CSVWalls::deleteTurret(const NorvenTurret& turret)
{
	Turrets turrets{};
	loadDataFromCSV(turrets, this->fileLocation);
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to remove, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	turrets.erase(searchResult);

	saveDataToCSV(turrets, this->fileLocation);
}

void loadDataFromHTML(Turrets& turrets, const string& path)
{
	string line{};
	ifstream inputFile(path);
	while (getline(inputFile, line) && line.find("</tr>") == -1)
	{
		continue;
	}

	string attributes{};
	while (getline(inputFile, line))
	{
		if (line == "")
			break;
		if (line.find("<tr>") != -1)
		{
			getline(inputFile, line);
		}
		if (line.find("</tr>") != -1)
		{
			attributes.pop_back();
			attributes.pop_back(); // eliminate ", " at the ending of attributes
			istringstream input(attributes);
			NorvenTurret turret{};
			input >> turret;
			turrets.push_back(turret);
			attributes = "";
		}
		else if( line.find("<td>") != -1)
		{
			int begin = line.find("<td>")+4; // <td> -4 characters
			int end = line.find("</td>");
			string attribute = line.substr(begin, end - begin);
			attributes += attribute + ", ";
		}
	}
}

void saveDataToHTML(Turrets& turrets, const string& path)
{
	ofstream outputFile{ path };
	string file = "<!DOCTYPE html>\n<html>\n\t<head>\n\t\t<title> Turrets on the Walls </title>\n\t</head>\n\t<body>\n\t\t<table border=\"1\">\n";
	file += "\t\t<tr>\n\t\t\t<td> Location </td>\n\t\t\t<td> Size </td>\n\t\t\t<td> AuraLevel </td>\n\t\t\t<td> SeparateParts </td>\n";
	file += "\t\t\t<td> Vision </td>\n\t\t</tr>\n";
	for (auto turret : turrets)
	{
		file += "\t\t<tr>\n";

		string line{};
		ostringstream output(line);
		output << turret;
		line = output.str();
		int position{};
		int begin = 0;
		line.pop_back();
		position = line.find(", ");
		while (position != -1)
		{
			
			file += "\t\t\t<td>";
			file += line.substr(begin, position);
			line.erase(begin, position + 2);
			file += "</td>\n";
			position = line.find(", ");
		}
		file += "\t\t\t<td>";
		file += line.substr(begin, line.size());
		file += "</td>\n";

		file += "\t\t</tr>\n";
		output.str("");
		output.clear();
	}
	file += "\t\t</table>\n\t</body>\n</html>";
	outputFile << file;
}

HTMLWalls::HTMLWalls(const string mylistLocation)
{
	this->fileLocation = mylistLocation;
}

void HTMLWalls::addTurret(const NorvenTurret& turret)
{
	Turrets turrets{};
	loadDataFromHTML(turrets, this->fileLocation);
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	//if the turret we want to add does already exist in the repo, throw an error
	if (find(first, last, turret) != last)
		throw RepoError();

	turrets.insert(last, turret);

	saveDataToHTML(turrets, this->fileLocation);
}

Turrets HTMLWalls::getTurretsOnWalls() const
{
	Turrets turrets{};
	loadDataFromHTML(turrets, this->fileLocation);
	return turrets;
}

string& HTMLWalls::getFileLocation()
{
	return this->fileLocation;
}


void HTMLWalls::deleteTurret(const NorvenTurret& turret)
{
	Turrets turrets{};
	loadDataFromHTML(turrets, this->fileLocation);
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to remove, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	turrets.erase(searchResult);

	saveDataToHTML(turrets, this->fileLocation);
}