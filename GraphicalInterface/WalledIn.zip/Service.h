#pragma once
#include "Repository.h"
#include "Walls.h"

class Enchantment
{
private:

	Encyclopedia* encyclopedia;
	Walls* walls;

public:

	// The Constructor
	Enchantment(Encyclopedia* repo, Walls* repoWalls) : encyclopedia{ repo }, walls{ repoWalls } {};

	/*
	returns a const reference to the turrets from the Encyclopedia
	*/
	Turrets getAllTurretsInEncyclopedia() const;


	/*
	creates a turret and adds it to Encyclopedia

	Input:	const string& - the location
			const string& - the size
			const string& - the vision
			int - auraLevel
			int - separateParts
	*/
	void addTurretToEncyclopedia(const string& location, const string& size, int auraLevel, int separateParts, const string& vision);


	/*
	deletes a turret from the Encyclopedia by a given location
	*/
	void deleteTurretFromEncyclopedia(const string& location);


	/*
	modifies a turret and in the Encyclopedia

	Input:	const string& - the location
			const string& - the size
			const string& - the vision
			int - auraLevel
			int - separateParts
	*/
	void updateTurretFromEncyclopedia(const string& location, const string& size, int auraLevel, int separateParts, const string& vision);


	/*
	returns a const reference to the turrets on the Walls

	Input: -
	Output: const DynamicVector<NorvenTurret>& - the turrets on Walls
	*/
	Turrets getAllTurretsOnWalls() const;

	/*
	returns a const reference to the next turret on the Walls

	Input: -
	Output: const DynamicVector<NorvenTurret>& - the next turret on Walls
	*/
	NorvenTurret next();

	/*
	adds a turret on the Walls by a given location

	Input: const string& - the location
	*/
	void saveTurretOnWalls(const string&);

	NorvenTurret getCurrentTurret() const;

	void deleteTurretFromWalls(const string& location);

	string& getPath();
};