#pragma once
#include "Domain.h"
#include "Service.h"
#include "Exceptions.h"

#include <QWidget>
#include "ui_ModeB.h"

class ModeB : public QWidget
{
	Q_OBJECT

public:
	ModeB(Enchantment& _enchantment, QWidget *parent = Q_NULLPTR);
	~ModeB();

private:
	Enchantment& enchantment;

	Ui::ModeB uiModeB;

public slots:
	void toMainPage();
	void next();
	void save();
	void populateList();
	void openExternally();
	void deleteFromList();
	int getSelectedIndex() const;

signals:
	void goHomeClick();
};
