#include "Repository.h"
#include <algorithm>
#include <iostream>
#include <fstream>
#include "Exceptions.h"

Turrets loadDataFromFile(string filename)
{
	ifstream inputFile{ filename };
	Turrets turrets;
	NorvenTurret turret{};
	while (inputFile >> turret)
	{
		turrets.insert(turrets.end(), turret);
	}
	inputFile.close();
	return turrets;

}


void writeDataToFile(string filename, Turrets& turrets)
{
	ofstream outputFile{ filename };
	for (auto turret : turrets)
		outputFile << turret;
	outputFile.close();
}


FileRepo::FileRepo(const string _fileLocation): Encyclopedia{}, filename{_fileLocation}
{
	this->filename = _fileLocation;
}

Turrets FileRepo::getTurrets()
{
	Turrets turrets = loadDataFromFile(this->filename);
	return turrets;
}

void FileRepo::addTurret(const NorvenTurret& turret)
{
	Turrets turrets = loadDataFromFile(this->filename);

	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	//if the turret we want to add does already exist in the repo, throw an error
	if (find(first, last, turret) != last)
		throw RepoError();

	turrets.insert(last, turret);

	writeDataToFile(this->filename, turrets);
}

void FileRepo::deleteTurret(const NorvenTurret& turret)
{
	Turrets turrets = loadDataFromFile(this->filename);

	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to remove, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	turrets.erase(searchResult);
	writeDataToFile(this->filename, turrets);
}

void FileRepo::updateTurret(const NorvenTurret& newTurret)
{
	Turrets turrets = loadDataFromFile(this->filename);

	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, newTurret);

	//if the turret we want to modify, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	NorvenTurret& turret = *searchResult;
	turret.setLocation(newTurret.getLocation());
	turret.setSize(newTurret.getSize());
	turret.setAuraLevel(newTurret.getAuraLevel());
	turret.setSeparateParts(newTurret.getSeparateParts());
	turret.setVision(newTurret.getVision());

	writeDataToFile(this->filename, turrets);
}


NorvenTurret FileRepo::findTurretByLocation(const string& location)
{
	Turrets turrets = loadDataFromFile(this->filename);
	
	NorvenTurret turret(location, string(), int(), int(), string());

	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to find, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	return *searchResult;
}

NorvenTurret FileRepo::nextTurret()
{
	Turrets turrets = loadDataFromFile(this->filename);

	if (this->currentTurret == turrets.size())
		this->currentTurret = 0; 
	return turrets[currentTurret++];
}

Encyclopedia::Encyclopedia()
{
}

InMeomoryRepo::InMeomoryRepo()
{
}

Turrets InMeomoryRepo::getTurrets()
{
	return this->turrets;
}

void InMeomoryRepo::addTurret(const NorvenTurret& turret)
{
	Turrets::iterator first = this->turrets.begin();
	Turrets::iterator last = this->turrets.end();

	//if the turret we want to add does already exist in the repo, throw an error
	if (find(first, last, turret) != last)
		throw RepoError();

	turrets.insert(last, turret);
}

void InMeomoryRepo::deleteTurret(const NorvenTurret& turret)
{
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to remove, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	turrets.erase(searchResult);
}

void InMeomoryRepo::updateTurret(const NorvenTurret& newTurret)
{
	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, newTurret);

	//if the turret we want to modify, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	NorvenTurret& turret = *searchResult;
	turret.setLocation(newTurret.getLocation());
	turret.setSize(newTurret.getSize());
	turret.setAuraLevel(newTurret.getAuraLevel());
	turret.setSeparateParts(newTurret.getSeparateParts());
	turret.setVision(newTurret.getVision());
}


NorvenTurret InMeomoryRepo::findTurretByLocation(const string& location)
{
	NorvenTurret turret(location, string(), int(), int(), string());

	Turrets::iterator first = turrets.begin();
	Turrets::iterator last = turrets.end();

	Turrets::iterator searchResult = find(first, last, turret);

	//if the turret we want to find, does not exist in the repo, throw an error
	if (searchResult == last)
		throw RepoError();

	return *searchResult;
}

NorvenTurret InMeomoryRepo::nextTurret()
{
	if (this->turrets.size() == 0)
		throw RepoError();

	if (this->currentTurret == turrets.size())
		this->currentTurret = 0;
	return turrets[currentTurret++];
}

int InMeomoryRepo::getCurrent() const
{
	return this->currentTurret;
}

int FileRepo::getCurrent() const
{
	return this->currentTurret;
}