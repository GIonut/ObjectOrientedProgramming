#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_WalledIn.h"
#include "Service.h"

class WalledIn : public QMainWindow
{
	Q_OBJECT

public:
	WalledIn(Enchantment& _enchantment, QWidget *parent = Q_NULLPTR);

private:
	Enchantment& enchantment;

	Ui::WalledInClass ui;

	void populateList();
	void connectSignalsAndSlots();
	int getSelectedIndex() const;

public slots:
	void addTurret();
	void deleteTurret();
	void showChart();
	void updateTurret();
	void toMainPage();
	void filter();

signals:
	void goHomeClick();
	void deleteFromWalls();
};
