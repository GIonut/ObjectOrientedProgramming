#pragma once
#include <vector>
#include "Domain.h"
typedef vector<NorvenTurret> Turrets;

class Walls
{
public:

	/*
	adding a NorvenTurret in the dynamicVector

	Input: const NorvenTurret& - the NorvenTurret to be added
	*/
	virtual void addTurret(const NorvenTurret&) = 0;


	/*
	returns a const reference to the dynamicVector
	*/
	virtual Turrets getTurretsOnWalls() const = 0;


	virtual string& getFileLocation() = 0;

	virtual void deleteTurret(const NorvenTurret& turret) = 0;

	virtual ~Walls() {};

};

class CSVWalls : public Walls
{
private:

	string fileLocation{};

public:

	CSVWalls(const string);

	void addTurret(const NorvenTurret&);

	Turrets getTurretsOnWalls() const;
	
	string& getFileLocation();

	void deleteTurret(const NorvenTurret& turret) override;

};


class HTMLWalls : public Walls
{
private:

	string fileLocation{};

public:

	HTMLWalls(string);

	void addTurret(const NorvenTurret&);

	Turrets getTurretsOnWalls() const;

	string& getFileLocation();

	void deleteTurret(const NorvenTurret& turret) override;

};