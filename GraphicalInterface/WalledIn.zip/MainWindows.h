#pragma once

#include <QWidget>
#include "ui_MainWindows.h"

#include "ModeB.h"
#include "WalledIn.h"
#include <memory>

class MainWindows : public QWidget
{
	Q_OBJECT

public:
	MainWindows(Enchantment& _enchantment, QWidget *parent = Q_NULLPTR);
	~MainWindows();

private:
	Enchantment& enchantment;

	Ui::MainWindows uiMainWindows;
	ModeB _modeB{ enchantment };
	WalledIn _modeA{ enchantment };
	

public slots:
	void toMainPage();
	void switchToModeB();
	void switchToModeA();
};
