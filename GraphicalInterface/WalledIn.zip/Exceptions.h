#pragma once
#include <exception>

using namespace std;

struct RepoError : public exception
{
	const char* details() const throw()
	{
		return "RepoError!";
	}

};

struct ValidationError : public exception
{
	const char* details() const throw()
	{
		return "ValidationError!";
	}
};