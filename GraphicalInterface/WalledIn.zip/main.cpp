#include "WalledIn.h"
#include <QtWidgets/QApplication>

#include "Repository.h"
#include "Walls.h"
#include "Service.h"
#include "MainWindows.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	ifstream f("configFile.txt");
	string repositoryRepresentation;
	string mylistRepresentation;
	string spareWords;
	f >> spareWords >> spareWords >> repositoryRepresentation;

	unique_ptr<Encyclopedia> encyclopedia;

	if (repositoryRepresentation == "FileBased")
		encyclopedia = make_unique<FileRepo>("turrets.txt");
	else
		encyclopedia = make_unique<InMeomoryRepo>();
	
	f >> spareWords >> spareWords >> mylistRepresentation;

	unique_ptr<Walls> walls;

	if (mylistRepresentation == "CSV")
		walls = make_unique<CSVWalls>("turrets.csv");
	else
		walls = make_unique<HTMLWalls>("turrets.html");

	Enchantment enchantment{ encyclopedia.get(), walls.get() };

	MainWindows gui{enchantment};
	gui.show();
	
	return a.exec();
}
