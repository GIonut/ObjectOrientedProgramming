#pragma once
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

class NorvenTurret
{
private:

	string location;
	string size;
	int auraLevel;
	int separateParts;
	string vision;

public:

	NorvenTurret();

	NorvenTurret(const string& location, const string& size, int auraLevel, int separateParts, const string& vision);

	friend istream& operator>>(istream& inputFile, NorvenTurret& turret);

	friend ostream& operator<<(ostream& outputFile, const NorvenTurret& turret);

	bool operator==(const NorvenTurret& other) const;

	const string& getVision() const { return vision; };

	const string& getSize() const { return size; };

	const string& getLocation() const { return location; };

	const int& getAuraLevel() const { return auraLevel; };

	const int& getSeparateParts() const { return separateParts; };

	void setVision(const string& newVision) { vision = newVision; };

	void setSize(const string& newSize) { size = newSize; };

	void setLocation(const string& newLocation) { location = newLocation; };

	void setAuraLevel(int newAuraLevel) { auraLevel = newAuraLevel; };

	void setSeparateParts(int newSeparateParts) { separateParts = newSeparateParts; };
};