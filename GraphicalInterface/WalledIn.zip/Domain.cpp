#include "Domain.h"
#include "Exceptions.h"

NorvenTurret::NorvenTurret() : location(""), size(""), auraLevel(), separateParts(), vision("") {};

NorvenTurret::NorvenTurret(const string& location, const string& size, int auraLevel, int separateParts, const string& vision)
{
	this->location = location;
	this->size = size;
	this->auraLevel = auraLevel;
	this->separateParts = separateParts;
	this->vision = vision;
}

istream& operator>>(istream& inputFile, NorvenTurret& turret)
{
	string line{};

	getline(inputFile, line);
	if (line.size() == 0)
		return inputFile;
	string atributes[5]{}; //a Norven Turret has 5 attributes

	int i = 0;
	while (i < 4)// starting from 0, there are 5 atributes until the 4th index
	{
		int end = line.find(", ");
		atributes[i] = line.substr(0, end);
		line = line.erase(0, end + 2);// 0 is the beginning, 2 is for ", " group of characters
		i++;
	}
	atributes[4] = line;// 4- the index of last atribute
	turret.location = atributes[0];// 0 - the index for first atribute
	turret.size = atributes[1];// 1 - the index for the second atribute
	try {
		turret.auraLevel = stoi(atributes[2]);// 2 - the index for third atribute
		turret.separateParts = stoi(atributes[3]);// 3 - the index for forth atribute
	}
	catch (...)
	{
		throw ValidationError();
	}
	turret.vision = atributes[4];

	return inputFile;
}

ostream& operator<<(ostream& outputFile, const NorvenTurret& turret)
{
	string line{};
	line += turret.getLocation() + ", " + turret.getSize() + ", " + to_string(turret.getAuraLevel());
	line += ", " + to_string(turret.getSeparateParts()) + ", " + turret.getVision()+"\n";

	outputFile << line;

	return outputFile;
}

bool NorvenTurret::operator==(const NorvenTurret& other) const
{
	return(location == other.getLocation());
}
