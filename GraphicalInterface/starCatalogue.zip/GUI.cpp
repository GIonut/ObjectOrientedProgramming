#include "GUI.h"
#include <qmessagebox.h>
#include<qpainter.h>
#include"Drawing.h"
GUI::GUI(Service& _service, Astronomer _astronomer, Model* _model, QWidget *parent)
    : QMainWindow(parent), service(_service), astronomer(_astronomer), model(_model)
{
    ui.setupUi(this);
    this->setWindowTitle(QString::fromStdString(astronomer.name));
    ui.tableView->setModel(model);
    ui.tableView->resizeColumnsToContents();
    ui.tableView->resizeRowsToContents();
    ui.tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

void GUI::filter()
{
    if (this->change == false)
    {
        this->change = true;
        this->model->change(this->astronomer);
    }
    else
    {
        this->change = false;
        Astronomer empty;
        this->model->change(empty);
    }
}

void GUI::update()
{
    this->model->update();
}

int GUI::getSelectedIndex()
{
    QModelIndexList selectedIndexes = this->ui.tableView->selectionModel()->selectedIndexes();

    if (selectedIndexes.size() == 0)
    {
        return -1;
    }

    int selectedIndex = selectedIndexes.at(0).row();
    return selectedIndex;
}

void GUI::add()
{
    string name = this->ui.lineEdit->text().toStdString();
    string constellation = this->astronomer.constellation;
    string RA = this->ui.lineEdit_2->text().toStdString();
    string Dec = this->ui.lineEdit_3->text().toStdString();
    string diameter = this->ui.lineEdit_4->text().toStdString();

    try
    {
        this->service.add(name, constellation, stoi(RA), stoi(Dec), stoi(diameter));
    }
    catch (exception& e)
    {
        QMessageBox::critical(this, "Error", e.what());
        return;
    }

    this->update();
}

void GUI::search()
{
    this->ui.listWidget->clear();

    string name = this->ui.lineEdit->text().toStdString();

    auto elements = this->service.search(name);

    for (Star& element : elements)
    {
        this->ui.listWidget->addItem(QString::fromStdString(element.toString()));
    }

}

void GUI::select(int index)
{
    Star star = this->model->elements[index];
    
    Drawing* drawing = new Drawing(this->service, star);
    drawing->setWindowTitle(QString::fromStdString(star.constellation));
    drawing->show();
}

void GUI::view()
{
    int index = this->getSelectedIndex();
    this->select(index);
}
