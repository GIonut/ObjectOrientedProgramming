#include "drawing.h"
#include <QPainter>
#include <QKeyEvent>
#include <QDebug>

Drawing::Drawing(Service& _service, Star _star, QWidget* parent) : QWidget{ parent }, star(_star), service(_service)
{
}

Drawing::~Drawing()
{
}

QSize Drawing::sizeHint() const
{
	return QSize{ 600, 400 };
}

void Drawing::paintEllipse()
{
	QPainter painter{ this };
	painter.eraseRect(0, 0, 600, 400);

	// draw an ellipse
	QPen pen{ Qt::black, 1, Qt::SolidLine, Qt::RoundCap };
	painter.setPen(pen);
	for(auto element : this->service.stars)
		if(element.constellation == star.constellation && element.name != star.name)
			painter.drawEllipse(element.RA, element.Dec, element.diameter, element.diameter);
	QPen pen1{ Qt::red, 1, Qt::SolidLine, Qt::RoundCap };
	painter.setPen(pen1);
	painter.drawEllipse(star.RA, star.Dec, star.diameter, star.diameter);

}

void Drawing::paintEvent(QPaintEvent* event)
{
	this->paintEllipse();

}
