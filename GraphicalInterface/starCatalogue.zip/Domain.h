#pragma once
#include<string>
#include<iostream>
using namespace std;

class Astronomer
{
public:
	string name;
	string constellation;
	friend istream& operator>>(istream& reader, Astronomer& astronomer);
};

class Star
{
public:
	string name;
	string constellation;
	int RA;
	int Dec;
	int diameter;
	Star() {};
	Star(string name, string constellation, int RA, int Dec, int diameter);
	friend ostream& operator<<(ostream & writer, Star & star);
	friend istream& operator>>(istream& reader, Star& star);
	string toString();
};
