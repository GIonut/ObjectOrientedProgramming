#include "Domain.h"
#include <sstream>

istream& operator>>(istream& reader, Astronomer& astronomer)
{
	string line;
	getline(reader, line);
	stringstream ss(line);
	getline(ss, astronomer.name, ';');
	getline(ss, astronomer.constellation, ';');
	return reader;
}

ostream& operator<<(ostream& writer, Star& star)
{
	writer << star.name << ";" << star.constellation << ";" << star.RA << ";" << star.Dec << ";" << star.diameter;
	return writer;
}

istream& operator>>(istream& reader, Star& star)
{
	string line;
	getline(reader, line);
	if (line.empty())
		return reader;
	stringstream ss(line);
	getline(ss, star.name, ';');
	getline(ss, star.constellation, ';');
	string RA;
	getline(ss, RA, ';');
	star.RA = stoi(RA);
	string Dec;
	getline(ss, Dec, ';');
	star.Dec = stoi(Dec);
	string diameter;
	getline(ss, diameter, ';');
	star.diameter = stoi(diameter);
	return reader;
}

Star::Star(string name, string constellation, int RA, int Dec, int diameter): name(name), constellation(constellation), RA(RA), Dec(Dec), diameter(diameter)
{
}

string Star::toString()
{
	return this->name + " " + this->constellation + " " + to_string(this->RA) + " " + to_string(this->Dec) + " " + to_string(this->diameter);
}
