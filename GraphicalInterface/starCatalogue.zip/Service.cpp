#include "Service.h"
#include<fstream>

Service::Service(string file1, string file2): file1(file1), file2(file2)
{
	ifstream fin1(file1);
	Astronomer astronomer;
	while (fin1 >> astronomer)
		this->astronomers.push_back(astronomer);
	fin1.close();
	ifstream fin2(file2);
	Star star;
	while (fin2 >> star)
		this->stars.push_back(star);
	fin2.close();
}

Service::~Service()
{
	ofstream fout(file2);
	for (auto star : this->stars)
		fout << star << "\n";
	fout.close();
}

vector<Star> Service::filter(Astronomer astronomer)
{
	vector<Star> elements;
	for (auto star : stars)
	{
		if (star.constellation == astronomer.constellation)
			elements.push_back(star);
	}
	return elements;
}

void Service::add(string name, string constellation, int RA, int Dec, int diameter)
{
	if (name.empty() || diameter <= 0)
		throw exception("invalid object!");
	for (auto star : this->stars)
	{
		if(star.name == name)
			throw exception("invalid object!");
	}

	Star star(name, constellation, RA, Dec, diameter);
	this->stars.push_back(star);
	this->notify();
}

vector<Star> Service::search(string _name)
{
	vector<Star> elements;
	for (auto element : stars)
		if (element.name.find(_name) != string::npos)
			elements.push_back(element);
	return elements;
}
