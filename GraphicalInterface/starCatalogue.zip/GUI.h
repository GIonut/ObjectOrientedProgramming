#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_GUI.h"
#include "Service.h"
#include "Domain.h"
#include "Model.h"
#include "Observer.h"
using namespace std;

class GUI : public QMainWindow, public Observer
{
    Q_OBJECT

public:
    GUI(Service& _service, Astronomer _astronomer, Model* _model, QWidget *parent = Q_NULLPTR);

private:
    Ui::GUIClass ui;
    Service& service;
    Model* model;
    Astronomer astronomer;

    bool change = false;

    void update() override;
    int getSelectedIndex();
    void select(int index);

public slots:
    void filter();
    void add();
    void search();
    void view();
};
