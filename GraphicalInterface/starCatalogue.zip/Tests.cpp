#include "Tests.h"
#include<assert.h>
void Tests::testAdd()
{
	FakeService service{};
	assert(service.stars.size() == 0);
	service.add("a", "b", 1, 1, 1);
	assert(service.stars.size() == 1);
	assert(service.stars[0].toString() == "a b 1 1 1");
	try
	{
		service.add("", "b", 1, 1, 1);
		assert(false);
	}
	catch (exception& e)
	{
		assert(strcmp(e.what(), "invalid object!") == 0);
	}
	assert(service.stars.size() == 1);
	try
	{
		service.add("a", "c", 2, 2, 2);
		assert(false);
	}
	catch (exception& e)
	{
		assert(string(e.what()) == "invalid object!");
	}
	assert(service.stars.size() == 1);
	try
	{
		service.add("c", "b", 1, 1, 0);
		assert(false);
	}
	catch (exception& e)
	{
		assert(string(e.what()) == "invalid object!");
	}
	assert(service.stars.size() == 1);
}
