#pragma once
#include "Service.h"
#include<vector>
#include<string>
#include <qabstractitemmodel.h>

using namespace std;

class Model: public QAbstractTableModel
{
	Service& service;
public:
	vector<Star> elements;
	Model(Service& _service) : service{ _service } { elements = this->service.stars; };
	int rowCount(const QModelIndex& parent = QModelIndex()) const;
	int columnCount(const QModelIndex& parent = QModelIndex()) const;
	QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const;
	QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const;
	Qt::ItemFlags flags(const QModelIndex& index) const;
	void reset();

	void change(Astronomer astronomer);
	void update();
};

