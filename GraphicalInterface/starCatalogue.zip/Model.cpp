#include "Model.h"

int Model::rowCount(const QModelIndex& parent) const
{
	return this->elements.size();
}

int Model::columnCount(const QModelIndex& parent) const
{
	return 5;
}

QVariant Model::data(const QModelIndex& index, int role) const
{
	int row = index.row();
	int column = index.column();

	Star star = this->elements[row];

	if (role == Qt::DisplayRole)
	{
		switch (column)
		{
		case 0:
			return QString::fromStdString(star.name);
		case 1:
			return QString::fromStdString(star.constellation);
		case 2:
			return QString::number(star.RA);
		case 3:
			return QString::number(star.Dec);
		case 4:
			return QString::number(star.diameter);
		default:
			break;
		}
	}
	return QVariant();
}

QVariant Model::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal)
		{
			switch (section)
			{
			case 0:
				return QString("name");
			case 1:
				return QString("constellation");
			case 2:
				return QString("RA");
			case 3:
				return QString("Dec");
			case 4:
				return QString("diameter");
			default:
				break;
			}
		}

		if (orientation == Qt::Vertical)
		{
			return section + 1;
		}
	}
	return QVariant();
}

Qt::ItemFlags Model::flags(const QModelIndex& index) const
{
	if(index.column() == 0)
		return Qt::ItemIsEnabled | Qt::ItemIsSelectable;
	return Qt::ItemFlags();
}

void Model::reset()
{
	this->beginResetModel();
	this->endResetModel();
}

void Model::change(Astronomer astronomer)
{
	if (astronomer.name.empty())
		this->elements = this->service.stars;
	else
		this->elements = this->service.filter(astronomer);
	this->reset();
}

void Model::update()
{
	this->elements = this->service.stars;
	this->reset();
}
