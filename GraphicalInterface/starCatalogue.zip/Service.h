#pragma once
#include<vector>
#include<string>
#include "Domain.h"
#include "Observer.h""
using namespace std;

class Service : public Subject
{
	string file1;
	string file2;
public:
	vector<Astronomer> astronomers;
	vector<Star> stars;
	Service() {};
	Service(string file1, string file2);
	~Service();
	vector<Star> filter(Astronomer astronomer);

	//function that adds an element of type star to the vector of star, if it is a valid element:
	//name is not empty, diameter is greater than 0 
	//and there is no other star element in the vector of star with the same name
	//otherwise throw an error
	//input:	string: name, constellation
	//			int: RA, Dec, diameter
	//output: nothing, throws an error if the element if the element is not valid
	void add(string name, string constellation, int RA, int Dec, int diameter);
	vector<Star> search(string _name);
};

