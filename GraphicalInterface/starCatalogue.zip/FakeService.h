#pragma once
#include "Service.h"

class FakeService: public Service
{
public:
	FakeService() {};
};

