#pragma once

#include <QWidget>
#include "ui_Drawing.h"
#include"Domain.h"
#include"Service.h"
class Drawing : public QWidget
{
	Q_OBJECT

public:
	Drawing(Service& service, Star _star, QWidget *parent = Q_NULLPTR);
	~Drawing();

private:
	Ui::Drawing ui;
	Star star;
	Service& service;
	void paintEllipse();
	QSize sizeHint() const Q_DECL_OVERRIDE;
	void paintEvent(QPaintEvent* event) override;
};
