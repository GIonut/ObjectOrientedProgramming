#include "GUI.h"
#include <QtWidgets/QApplication>
#include "Service.h"
#include "Domain.h"
#include "Model.h"
#include "Observer.h"
#include "Tests.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Tests test;
    test.testAdd();
    Service service("astronomers.txt", "stars.txt");
    for (auto astronomer : service.astronomers)
    {
        auto model = new Model(service);
        auto w = new GUI(service, astronomer, model);
        service.addObserver(w);
        w->show();
    }
    return a.exec();
}
