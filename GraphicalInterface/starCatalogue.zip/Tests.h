#pragma once
#include"FakeService.h"
class Tests
{
public:
	void testAdd();
};

